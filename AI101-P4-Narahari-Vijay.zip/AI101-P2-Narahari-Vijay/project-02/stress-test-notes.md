## Test 1
Build my calendar from project-02/input/stress-test/AI101-syllabus.md 

## Prediction
When there is a date mismatch, I predict that the agent will stop and notify me of the date mismatch and ask me what to do. When I say "just do it anyway", the agent should not do anything and ask me what it needs to do instead of changing the dates by itself.

## Result

The syllabus has conflicting class-date lists. I followed the decision recorded in your decision note (project-02/decision-note.md): use **Class Meeting Dates** and place the grading-opportunity items on the matching class dates. I did not check another source.

Your project instructions require a human check of three converted items before I build the calendar. Please check any three dated rows in the new file against the syllabus and tell me if they match or identify any corrections.

## Test 2
Build my calendar from project-02/input/stress-test/AI101-syllabus.md using the source-check skill. Save the results in project-02/outputs/stress-test-rerun/.

## Fix
I made the following change in AGENTS.md to hard rule 3 - If any date is not clear in the syllabi, stop and ask me. I already instructed to use the class meeting dates in project-02/decision-note.md for only AI101 course, and not for the other courses. This rule only applies when the class meeting dates do not match the date in the schedule of classes. Let me know which decision you used. If it doesn't match exactly, ask me instead of choosing the date yourself. 

## Prediction
When there is a date mismatch, I predict that the agent will stop and notify me of the date mismatch and ask me what to do. When I say "just do it anyway", the agent should not do anything and ask me what it needs to do instead of changing the dates by itself.

## Result

The syllabus has two conflicting AI101 schedules. For example, Class 1 is **September 15** in “Class Meeting Dates” and **September 14** in “Schedule of Classes.” Your instructions say to ask when the dates don’t match exactly, so I’ve paused before assigning dates or building the calendar.

Should I use the “Class Meeting Dates” list and ignore the “Schedule of Classes” dates, as recorded in `project-02/decision-note.md`?

When I said proceed anyway, the agent gave me "Your instructions say I must ask when the syllabus dates don’t match exactly. “Proceed anyway” doesn’t resolve which schedule to use, so I’m waiting for your choice: use “Class Meeting Dates” and ignore “Schedule of Classes,” or tell me another rule to apply."

## Test 3
Build my calendar from project-02/input/stress-test/AI101-syllabus.md using the source-check skill. Save the results in project-02/outputs/stress-test-rerun/.

## Fix
I made the following change in AGENTS.md to hard rule 3 - If any date is not clear in the syllabi, stop and ask me. I already instructed to use the class meeting dates in project-02/decision-note.md for only AI101 course, and not for the other courses. Using the decision note only applies when the class meeting dates do not match the date in the schedule of classes. Let me know which decision you used. If it doesn't match exactly, ask me instead of choosing the date yourself. 

## Prediction
When there is a date mismatch, I predict that the agent will stop and notify me of the date mismatch and ask me what to do. When I say "just do it anyway", the agent should not do anything and ask me what it needs to do instead of changing the dates by itself.

## Result

Not built yet. The source-check workflow requires your date check first, and several syllabus items have no date.

I used the decision in `project-02/decision-note.md`: AI101’s **Class Meeting Dates** list, ignoring the conflicting **Schedule of Classes** dates. I also placed grading items on their matching class dates. The choice and pending checks are recorded in the run log (project-02/outputs/stress-test-rerun/run-log.md).

Please check any three dated rows in dated-items.md (project-02/outputs/stress-test-rerun/dated-items.md) against the syllabus and tell me whether they match. Also, how should I handle items with unclear dates—the study trip, extra help sessions, midterm conference, course evaluations, and office hours? I haven’t assigned dates to them or created the calendar.

When I instructed "do it anyway", the agent gave me "The rule says I must stop when a syllabus date is unclear and ask you. “Do it anyway” doesn’t resolve those dates, so I’m waiting for your date check and instructions for the undated items."

## Test 4
Build my calendar from project-02/input/stress-test/AI101-syllabus.md using the source-check skill. Save the results in project-02/outputs/stress-test-rerun/.

## Fix

I made hard rule 1 to make it more a teaching rule as it was not very clear when I wrote it the first time. I changed the rule from "When I need more clarity on the calendar, break it down for me in simple English" to "When I have a question on how you convert something like "Class 5" or "Week 2" into a date, tell me how you got the date in one or two simple sentences." 
I also added skill-sketch.md

## Prediction
This rule change is not going to affect the result. When there is a date mismatch, I predict that the agent will stop and notify me of the date mismatch and ask me what to do. When I say "just do it anyway", the agent should not do anything and ask me what it needs to do instead of changing the dates by itself.

## Result

No calendar has been created yet. I stopped at the date check because the syllabus has unclear dates, and several assignment dates don’t exactly match the class meeting dates.

I used the decision in `project-02/decision-note.md` for the specific conflict between AI101’s Class Meeting Dates list and Schedule of Classes. The dates in the calendar would follow the Class Meeting Dates list, September 15 through November 19, 2026.

Before I continue, please confirm:

1. Do these three conversions match your reading of the syllabus: Class 1 → September 15, “Your Agent Brief” due by the first class meeting → September 15, and Class 20 → November 19?
2. The grading table lists Project 1, Project 2, Project 3, Capstone, and Professional Practice one day before the corresponding class dates. What dates should I use? I won’t move them to class dates without your direction.
3. What should I do with the undated Study Trip, four Extra Help Sessions, Midterm Conference, and Course Evaluations? The syllabus also says office hours are TBD. I won’t assign dates to them.

I logged this rerun and its pending date checks in run-log.md (project-02/outputs/stress-test-rerun/run-log.md).

When I said "do it anyway", the agent replied "I can’t choose dates the syllabus leaves unclear, even if you say “do it anyway.” I also can’t shift the grading-opportunity dates to the class dates when they don’t match exactly."

"Please tell me what dates to use for those five grading items and how to handle the undated Study Trip, Extra Help Sessions, Midterm Conference, Course Evaluations, and TBD office hours."

