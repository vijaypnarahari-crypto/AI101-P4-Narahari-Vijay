# Calendar — stress test (Step 3)

Built from `outputs/stress-test/dated-items.md` only. This is one syllabus, so cross-course overlap analysis is not included.

**Events:** 26 dated (AI101 26). **Not yet scheduled:** 6.

## Date handling and source check

The syllabus contains conflicting class-date lists. This calendar follows the decision in `project-02/decision-note.md`: use the **Class Meeting Dates** list, ignore the Schedule of Classes dates, and place grading-opportunity items on the matching class dates. The original grading-opportunity dates remain in `outputs/stress-test/dated-items.md`. The three-item human source check was bypassed at your request, so verify these dates against the syllabus before relying on them.

AI101 professor office hours are listed as TBD, so no recurring event was added.

## Week of Sep 14–Sep 20

| Date | Day | Course | Event |
| --- | --- | --- | --- |
| 2026-09-15 | Tue | AI101 | [AI101] Assignment: Your Agent Brief |
| 2026-09-15 | Tue | AI101 | [AI101] Class: Class 1: Set Up Your Practice |
| 2026-09-17 | Thu | AI101 | [AI101] Class: Class 2: Make Something |

## Week of Sep 21–Sep 27

| Date | Day | Course | Event |
| --- | --- | --- | --- |
| 2026-09-22 | Tue | AI101 | [AI101] Class: Class 3: See the Whole Room |
| 2026-09-24 | Thu | AI101 | [AI101] Class: Class 4: Name the Trade |
| 2026-09-24 | Thu | AI101 | [AI101] Project: Project 1: Make, Then Compare |

## Week of Sep 28–Oct 4

| Date | Day | Course | Event |
| --- | --- | --- | --- |
| 2026-09-29 | Tue | AI101 | [AI101] Class: Class 5: Name the Process |
| 2026-10-01 | Thu | AI101 | [AI101] Class: Class 6: Verify Your Sources |

## Week of Oct 5–Oct 11

| Date | Day | Course | Event |
| --- | --- | --- | --- |
| 2026-10-06 | Tue | AI101 | [AI101] Class: Class 7: Build a Pipeline |
| 2026-10-08 | Thu | AI101 | [AI101] Class: Class 8: Take Feedback, Iterate |
| 2026-10-08 | Thu | AI101 | [AI101] Project: Project 2: Small Orchestration |

## Week of Oct 12–Oct 18

| Date | Day | Course | Event |
| --- | --- | --- | --- |
| 2026-10-13 | Tue | AI101 | [AI101] Class: Class 9: Disclosure and Position |
| 2026-10-15 | Thu | AI101 | [AI101] Class: Class 10: Study Your Field |

## Week of Oct 19–Oct 25

| Date | Day | Course | Event |
| --- | --- | --- | --- |
| 2026-10-20 | Tue | AI101 | [AI101] Class: Class 11: Build for Your Field |
| 2026-10-22 | Thu | AI101 | [AI101] Class: Class 12: Crit and Revise |
| 2026-10-22 | Thu | AI101 | [AI101] Project: Project 3: Your Field, With AI |

## Week of Oct 26–Nov 1

| Date | Day | Course | Event |
| --- | --- | --- | --- |
| 2026-10-27 | Tue | AI101 | [AI101] Class: Class 13: Define Your Agent |
| 2026-10-29 | Thu | AI101 | [AI101] Class: Class 14: Assemble the Sources |

## Week of Nov 2–Nov 8

| Date | Day | Course | Event |
| --- | --- | --- | --- |
| 2026-11-03 | Tue | AI101 | [AI101] Class: Class 15: Build and Test |
| 2026-11-05 | Thu | AI101 | [AI101] Class: Class 16: Find the Failures |

## Week of Nov 9–Nov 15

| Date | Day | Course | Event |
| --- | --- | --- | --- |
| 2026-11-10 | Tue | AI101 | [AI101] Class: Class 17: Revise |
| 2026-11-12 | Thu | AI101 | [AI101] Class: Class 18: Confirm the Difference |

## Week of Nov 16–Nov 22

| Date | Day | Course | Event |
| --- | --- | --- | --- |
| 2026-11-17 | Tue | AI101 | [AI101] Class: Class 19: Demo and Defend |
| 2026-11-19 | Thu | AI101 | [AI101] Assignment: Professional Practice |
| 2026-11-19 | Thu | AI101 | [AI101] Class: Class 20: Reflect and Carry Forward |
| 2026-11-19 | Thu | AI101 | [AI101] Project: Capstone: Your Own Agent |

## Not yet scheduled

| Course | Event | As written |
| --- | --- | --- |
| AI101 | [AI101] Class: Study Trip 1 | 1 TBD and will announce on BB |
| AI101 | [AI101] Class: Extra Help Session 1 | 1: Extra Help Session are on Fridays, Date and Time will be announced on BB |
| AI101 | [AI101] Class: Extra Help Session 2 | 2: Extra Help Session are on Fridays, Date and Time will be announced on BB |
| AI101 | [AI101] Class: Extra Help Session 4 | 4: Extra Help Session are on Fridays, Date and Time will be announced on BB |
| AI101 | [AI101] Class: Extra Help Session 3 | 3: Extra Help Session are on Fridays, Date and Time will be announced on BB |
| AI101 | [AI101] Class: Midterm Conference(s) | scheduled outside of class time with the professor |
