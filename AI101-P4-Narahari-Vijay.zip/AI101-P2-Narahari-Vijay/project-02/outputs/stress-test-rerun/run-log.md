# Run log — 2026-10-20

- **Asked:** Build a calendar from `project-02/input/stress-test/AI101-syllabus.md` using source-check, saving results in this folder.
- **Changed:** Created `dated-items.md` for this rerun. No calendar or overlap report created yet because the required human date check and unclear-date questions are still open.
- **Keep:** Applied the decision in `project-02/decision-note.md`: use the AI101 “Class Meeting Dates” list, disregard the conflicting “Schedule of Classes” dates, and align grading-opportunity dates to the matching class dates. This is the decision used for this extraction.
- **Change:** None from the recorded decision.
- **Reject:** None.
- **Pending:** Human check of any three converted rows. The syllabus also leaves Study Trip 1, four Extra Help Sessions, the Midterm Conference, Course Evaluations, and office hours without a date or date range. Per the calendar-agent rules, no dates were invented; confirm how these should be handled before calendar creation.

- **Rerun asked:** Build the calendar from `project-02/input/stress-test/AI101-syllabus.md` using source-check.
- **Changed:** No calendar written. Stopped at the date check because the syllabus has unresolved dates and the grading-opportunity dates do not exactly match AI101 class meeting dates.
- **Keep:** Used `project-02/decision-note.md` for the specific AI101 conflict between the Class Meeting Dates list and Schedule of Classes: the chosen class-date list is September 15 through November 19, 2026. This is the decision used.
- **Change:** None pending your date answers.
- **Reject:** Did not carry forward the prior rerun's shifts of grading due dates to class dates; the rule says to ask when the dates do not match exactly.
- **Pending:** Confirmation of three converted rows and dates/handling for the listed unresolved items. See this run's question in chat.
