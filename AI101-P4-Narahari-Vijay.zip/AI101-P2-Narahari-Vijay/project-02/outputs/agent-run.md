# Agent Run
- Date: 2026-10-23
- Input: project-02/input/Syllabi/AI101.pdf, ANIM223.pdf (same input as Project 2)
- Tool: Claudian (Claude Code in Obsidian), new conversation
- Workflow: project-02/00-start-here.md; step 2 called agents/date-extractor.md
- What I asked: Run my Project 2 workflow by following project-02/00-start-here.md. The input is project-02/input/Syllabi/AI101.pdf and project-02/input/Syllabi/ANIM223.pdf. Save the whole result in project-02/outputs/agent-run.md. Don’t overwrite any other file in project-02/outputs/.

# Agent run: AI101 + ANIM223 calendar (steps 2 and 3)

Run date: 2026-10-23. Sources: `input/Syllabi/AI101.pdf` and `input/Syllabi/ANIM223.pdf` only. Nothing is final until you finish the human check.

## Calendar

Sorted by date. NEEDS DATE rows are at the bottom. Updated 2026-10-23 after your human check: the five AI101 due dates now use the Class Meeting Dates.

| Course | Item (exact syllabus wording) | Type | As written | Calendar date | Notes |
|---|---|---|---|---|---|
| AI101 | Class 1: Set Up Your Practice | Class | Class 1 | 2026-09-15 (Tue) | UNIT 1: FOUNDATIONS (Classes 1-4). Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 9/14/26; Class Meeting Dates says 9/15/26. Used Class Meeting Dates (decision-note.md). |
| AI101 | Your Agent Brief | Assignment | Pre-quarter Assignment. Due Date: By the first class meeting. | 2026-09-15 (Tue) | Pre-quarter Assignment. First class meeting = Class 1 in Class Meeting Dates (decision-note.md applied; Schedule of Classes says 9/14/26). Please confirm. |
| ANIM223 | Class 1 | Class | Class 1 | 2026-09-15 (Tue) | UNIT 1: EARLY ANIMATION. Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: The Beginning. |
| ANIM223 | Reading: A New History of Animation - Chapters 1 &2 | Reading | Class 1 | 2026-09-15 (Tue) | Listed under Class 1 in the Schedule of Classes. Assigned reading, not a due date. |
| ANIM223 | Launch Assignment 1: Unit 1 Paper | Launch | Class 1 | 2026-09-15 (Tue) | Launch date, not a due date. 'Ongoing writing assignment summarizing textbook chapter readings.' Syllabus gives no separate due date for it. |
| AI101 | Class 2: Make Something | Class | Class 2 | 2026-09-17 (Thu) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 9/16/26; Class Meeting Dates says 9/17/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 2 | Class | Class 2 | 2026-09-17 (Thu) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Innovation & Experimentation in the early Silent Era. |
| AI101 | Class 3: See the Whole Room | Class | Class 3 | 2026-09-22 (Tue) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 9/21/26; Class Meeting Dates says 9/22/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 3 | Class | Class 3 | 2026-09-22 (Tue) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Growth of the Animation Industry in the 1920's. |
| ANIM223 | Reading: A New History of Animation - Chapters 3 & 4 | Reading | Class 3 | 2026-09-22 (Tue) | Listed under Class 3 in the Schedule of Classes. Assigned reading, not a due date. |
| ANIM223 | SCAD AnimationFest | Optional event | Wednesday, Sept. 23 - Friday, Sept. 25 | 2026-09-23 (Wed) | Suggested Extended Learning Opportunity, not required. Runs 2026-09-23 to 2026-09-25, SCADshow Theater, Atlanta. Syllabus gives no year; the weekdays only fit 2026. Start date shown. |
| AI101 | Class 4: Name the Trade | Class | Class 4 | 2026-09-24 (Thu) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 9/23/26; Class Meeting Dates says 9/24/26. Used Class Meeting Dates (decision-note.md). |
| AI101 | Project 1: Make, Then Compare | Project | Grading Opportunities: 9/23/26, weight 15% | 2026-09-24 (Thu) | Written 9/23/26 (Wed, no class). You chose the Class Meeting Date: Class 4, Thu 2026-09-24 (answered in step 2 check, 2026-10-23). |
| ANIM223 | Class 4 | Class | Class 4 | 2026-09-24 (Thu) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Animation Matures as an Art Form. |
| ANIM223 | Reading: A New History of Animation - Chapter 5 & 6 | Reading | Class 4 | 2026-09-24 (Thu) | Listed under Class 4 in the Schedule of Classes. Assigned reading, not a due date. |
| AI101 | Class 5: Name the Process | Class | Class 5 | 2026-09-29 (Tue) | UNIT 2: THE DESIGN PROCESS (Classes 5-8). Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 9/28/26; Class Meeting Dates says 9/29/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 5 | Class | Class 5 | 2026-09-29 (Tue) | UNIT 2: The Influence of Modernism. Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: First Features and Better Storytelling with Improved Believability. |
| AI101 | Class 6: Verify Your Sources | Class | Class 6 | 2026-10-01 (Thu) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 9/30/26; Class Meeting Dates says 10/1/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 6 | Class | Class 6 | 2026-10-01 (Thu) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Warner Bros.. |
| ANIM223 | Reading: A New History of Animation, Chapters 7 & 8 | Reading | Class 6 | 2026-10-01 (Thu) | Listed under Class 6 in the Schedule of Classes. Assigned reading, not a due date. |
| AI101 | Class 7: Build a Pipeline | Class | Class 7 | 2026-10-06 (Tue) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 10/5/26; Class Meeting Dates says 10/6/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 7 | Class | Class 7 | 2026-10-06 (Tue) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: MGM and other Hollywood studios. |
| AI101 | Class 8: Take Feedback, Iterate | Class | Class 8 | 2026-10-08 (Thu) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 10/7/26; Class Meeting Dates says 10/8/26. Used Class Meeting Dates (decision-note.md). |
| AI101 | Project 2: Small Orchestration | Project | Grading Opportunities: 10/7/26, weight 20% | 2026-10-08 (Thu) | Written 10/7/26 (Wed, no class). You chose the Class Meeting Date: Class 8, Thu 2026-10-08 (answered in step 2 check, 2026-10-23). |
| ANIM223 | Class 8 | Class | Class 8 | 2026-10-08 (Thu) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Wartime Animation. |
| ANIM223 | Reading: A New History of Animation, Chapter 9 | Reading | Class 8 | 2026-10-08 (Thu) | Listed under Class 8 in the Schedule of Classes. Assigned reading, not a due date. |
| AI101 | Class 9: Disclosure and Position | Class | Class 9 | 2026-10-13 (Tue) | UNIT 3: YOUR FIELD (Classes 9-12). Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 10/12/26; Class Meeting Dates says 10/13/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 9 | Class | Class 9 | 2026-10-13 (Tue) | UNIT 3: MODERN ERA. Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Post-War and Midcentury Developments. |
| ANIM223 | Reading: A New History of Animation, Chapters 10 & 11 | Reading | Class 9 | 2026-10-13 (Tue) | Listed under Class 9 in the Schedule of Classes. Assigned reading, not a due date. |
| AI101 | Class 10: Study Your Field | Class | Class 10 | 2026-10-15 (Thu) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 10/14/26; Class Meeting Dates says 10/15/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 10 | Class | Class 10 | 2026-10-15 (Thu) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Rise of Stop Motion. |
| ANIM223 | Launch Assignment 3: Unit 3 Paper | Launch | Class 10. Due by the beginning of Class 19 | 2026-10-15 (Thu) | Launch date. Syllabus says due by the beginning of Class 19 (Tue 2026-11-17). |
| ANIM223 | Assignment 1 - Written summaries of textbook chapters 1 thru 11 | Assignment | Grading Opportunities: 10/15/26, weight 15% | 2026-10-15 (Thu) | Matches Class 10 (Thu). DUE: Assignment 1 - Submit remaining textbook summaries of chapters 1 thru 11. |
| ANIM223 | Midterm Test | Test | Grading Opportunities: 10/15/26, weight 20% | 2026-10-15 (Thu) | Matches Class 10 (Thu). Schedule of Classes calls it 'DUE: Assignment 2 - Midterm Test - Multiple choice and short answer - In Class Only'. |
| ANIM223 | An extra help session will be available on Thursday week 5, from 2 pm tho 4 pm in room 309. | Help session | Extra Help Session 1: 10/15/26 | 2026-10-15 (Thu) | Date is written. 'Thursday week 5' also lands on 10/15/26 using Class Meeting Dates (Class 9 and 10 are week 5, Thursday = Class 10). Both agree. |
| ANIM223 | Digital Presence: Portfolios for Animators, VFX Artists, and More! | Optional event | Friday, Oct. 16 - 3pm - 4pm | 2026-10-16 (Fri) | Suggested Extended Learning Opportunity, not required. Deloitte Foundry, 3rd Floor Event Space. Syllabus gives no year; the weekday only fits 2026. |
| AI101 | Class 11: Build for Your Field | Class | Class 11 | 2026-10-20 (Tue) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 10/19/26; Class Meeting Dates says 10/20/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 11 | Class | Class 11 | 2026-10-20 (Tue) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Animation Moves to the Small Screen as Live Action Did. |
| ANIM223 | Reading: A New History of Animation, Chapters 12 & 13 | Reading | Class 11 | 2026-10-20 (Tue) | Listed under Class 11 in the Schedule of Classes. Assigned reading, not a due date. PDF line break splits it as 'Chapters 12' / '& 13'. |
| AI101 | Class 12: Crit and Revise | Class | Class 12 | 2026-10-22 (Thu) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 10/21/26; Class Meeting Dates says 10/22/26. Used Class Meeting Dates (decision-note.md). |
| AI101 | Project 3: Your Field, With AI | Project | Grading Opportunities: 10/21/26, weight 20% | 2026-10-22 (Thu) | Written 10/21/26 (Wed, no class). You chose the Class Meeting Date: Class 12, Thu 2026-10-22 (answered in step 2 check, 2026-10-23). |
| ANIM223 | Class 12 | Class | Class 12 | 2026-10-22 (Thu) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Experimentation and Computers. |
| ANIM223 | SCAD Savannah Film Festival | Optional event | Saturday, Oct. 24 - Saturday, Oct. 31 | 2026-10-24 (Sat) | Suggested Extended Learning Opportunity, not required. Runs 2026-10-24 to 2026-10-31. Syllabus gives no year; the weekdays only fit 2026. Start date shown. |
| AI101 | Class 13: Define Your Agent | Class | Class 13 | 2026-10-27 (Tue) | UNIT 4: ORCHESTRATION (Classes 13-20). Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 10/26/26; Class Meeting Dates says 10/27/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 13 | Class | Class 13 | 2026-10-27 (Tue) | UNIT 4: TRANSITION. Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: The Beginning of a Decline in Animated Theatrical Features. |
| ANIM223 | Reading: A New History of Animation, Chapters 14 & 15 | Reading | Class 13 | 2026-10-27 (Tue) | Listed under Class 13 in the Schedule of Classes. Assigned reading, not a due date. |
| AI101 | Class 14: Assemble the Sources | Class | Class 14 | 2026-10-29 (Thu) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 10/28/26; Class Meeting Dates says 10/29/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 14 | Class | Class 14 | 2026-10-29 (Thu) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Bluth, Bakshi, & Williams. |
| ANIM223 | Launch Assignment 4 Team Presentation Project | Launch | Class 14. All are Due by start of Class 19 | 2026-10-29 (Thu) | Launch date. Due by start of Class 19 (Tue 2026-11-17). Worth 25% of the course grade. Class 19 entry says final slides are due 'by the end of Class 19' (see flags). |
| AI101 | Class 15: Build and Test | Class | Class 15 | 2026-11-03 (Tue) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 11/2/26; Class Meeting Dates says 11/3/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 15 | Class | Class 15 | 2026-11-03 (Tue) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Animation Festivals & Short Films. |
| ANIM223 | Reading: A New History of Animation, Chapters 16, 17, & 18 | Reading | Class 15 | 2026-11-03 (Tue) | Listed under Class 15 in the Schedule of Classes. Assigned reading, not a due date. PDF layout puts Classes 15 and 16 side by side; this reading sits under the Festivals lecture, which I read as Class 15. |
| AI101 | Class 16: Find the Failures | Class | Class 16 | 2026-11-05 (Thu) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 11/4/26; Class Meeting Dates says 11/5/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 16 | Class | Class 16 | 2026-11-05 (Thu) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Animation in Canada. |
| ANIM223 | Jen Library Visit to view a selection of works from the Don Bluth Animation Production Collection from 10 am to 12 pm. | Trip | Study Trip 1: 11/7/26 | 2026-11-07 (Sat) | Saturday. No class that day. 10 am to 12 pm. |
| AI101 | Class 17: Revise | Class | Class 17 | 2026-11-10 (Tue) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 11/9/26; Class Meeting Dates says 11/10/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 17 | Class | Class 17 | 2026-11-10 (Tue) | UNIT 5: SECOND GOLDEN AGE. Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: The Disney Renaissance. |
| ANIM223 | Reading: A New History of Animation, Chapters 19 & 20 | Reading | Class 17 | 2026-11-10 (Tue) | Listed under Class 17 in the Schedule of Classes. Assigned reading, not a due date. |
| ANIM223 | Presentation Team Discussions - Assignment 4 | Event | Class 17 | 2026-11-10 (Tue) | In-class team time, not a due date. |
| AI101 | Class 18: Confirm the Difference | Class | Class 18 | 2026-11-12 (Thu) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 11/11/26; Class Meeting Dates says 11/12/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 18 | Class | Class 18 | 2026-11-12 (Thu) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Emergence of Electronic Games & 3D Experimentation. |
| ANIM223 | Reading: A New History of Animation, Chapters 21 & 22 | Reading | Class 18 | 2026-11-12 (Thu) | Listed under Class 18 in the Schedule of Classes. Assigned reading, not a due date. |
| AI101 | Class 19: Demo and Defend | Class | Class 19 | 2026-11-17 (Tue) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 11/16/26; Class Meeting Dates says 11/17/26. Used Class Meeting Dates (decision-note.md). |
| ANIM223 | Class 19 | Class | Class 19 | 2026-11-17 (Tue) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Japanese Animation. |
| ANIM223 | Assignment 3 -Written summaries of textbook chapters 12 thru 24 | Assignment | Grading Opportunities: 11/17/26, weight 20% | 2026-11-17 (Tue) | Matches Class 19 (Tue). DUE: Assignment 3 - Submit remaining textbook summaries of chapters 12 thru 24. |
| ANIM223 | Assignment 4 - Team Presentation Project | Project | Grading Opportunities: 11/17/26, weight 25% | 2026-11-17 (Tue) | Matches Class 19 (Tue). DUE: Assignment 4 - Team Presentation Project. 'The final submission of all slides is by the end of Class 19.' |
| AI101 | Class 20: Reflect and Carry Forward | Class | Class 20 | 2026-11-19 (Thu) | Tue/Thu 5:00 PM - 7:30 PM, SATLAB 123. Schedule of Classes says 11/18/26; Class Meeting Dates says 11/19/26. Used Class Meeting Dates (decision-note.md). |
| AI101 | Capstone: Your Own Agent | Project | Grading Opportunities: 11/18/26, weight 30% | 2026-11-19 (Thu) | Written 11/18/26 (Wed, no class). You chose the Class Meeting Date: Class 20, Thu 2026-11-19 (answered in step 2 check, 2026-10-23). |
| AI101 | Professional Practice | Graded item | Grading Opportunities: 11/18/26, weight 15 | 2026-11-19 (Thu) | Written 11/18/26 (Wed, no class). You chose the Class Meeting Date: Class 20, Thu 2026-11-19 (answered in step 2 check, 2026-10-23). |
| ANIM223 | Class 20 | Class | Class 20 | 2026-11-19 (Thu) | Tue/Thu 8:00 AM - 10:30 AM, MONTGO 309. Lecture: Technology and Entertainment. |
| ANIM223 | Final Test | Test | Grading Opportunities: 11/19/26, weight 20% | 2026-11-19 (Thu) | Matches Class 20 (Thu). Schedule of Classes calls it 'DUE: Assignment 5 - Final Test - Multiple choice and short answer - In Class Only'. |
| AI101 | Study Trip 1 | Trip | TBD and will announce on BB | NEEDS DATE | Study (Field) Trips table. No date in syllabus. |
| AI101 | Extra Help Session 1 | Help session | Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Day is Friday. Date and time not in syllabus. Syllabus table order is 1, 2, 4, 3. |
| AI101 | Extra Help Session 2 | Help session | Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Day is Friday. Date and time not in syllabus. Syllabus table order is 1, 2, 4, 3. |
| AI101 | Extra Help Session 3 | Help session | Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Day is Friday. Date and time not in syllabus. Syllabus table order is 1, 2, 4, 3. |
| AI101 | Extra Help Session 4 | Help session | Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Day is Friday. Date and time not in syllabus. Syllabus table order is 1, 2, 4, 3. |
| AI101 | Office Hours | Office hours | Office Hours: TBD, Zoom: https://scad.zoom.us/j/8382024752 | NEEDS DATE | Not listed in syllabus. |
| AI101 | Midterm Conference(s) | Event | Each student enrolled in the course will have a midterm conference scheduled outside of class time with the professor. | NEEDS DATE | No date given. |
| ANIM223 | Acquire the textbook & prepare for Class One | Assignment | Pre-quarter Assignment. Students will need to have a copy of the textbook by the beginning of the quarter | NEEDS DATE | Syllabus never gives the quarter start date. Class 1 is Tue 2026-09-15. Not chosen for you. |
| ANIM223 | Over the weekend teams will establish a team discord, discuss and determine their 1st and 2nd choice of topic. | Event | Class 14 (Launch Assignment 4): 'Over the weekend' | NEEDS DATE | Weekend after Class 14 (Thu 2026-10-29) is not named with a date. Not chosen for you. |
| ANIM223 | Office Hours: Fridays from 9am to 11 am | Office hours | Fridays from 9am to 11 am | NEEDS DATE | Weekly, Fridays. Syllabus gives no start or end date, so I did not build a repeating event. |
| ANIM223 | Midterm Conference(s) | Event | Each student enrolled in the course will have a midterm conference scheduled outside of class time with the professor. | NEEDS DATE | No date given. |

## Item counts

| Course | All items | With a date | NEEDS DATE |
|---|---|---|---|
| AI101 | 33 | 26 | 7 |
| ANIM223 | 49 | 45 | 4 |
| Total | 82 | 71 | 11 |

Without the 20 class meetings per course: AI101 has 13 items, ANIM223 has 29.

## Questions for you

### Due dates that didn't match a class meeting (AI101): ANSWERED
You chose the Class Meeting Date for all five. Moved on your word, not mine.

| Item | Written | Now |
|---|---|---|
| Project 1: Make, Then Compare | 9/23/26 (Wed) | Thu 2026-09-24 (Class 4) |
| Project 2: Small Orchestration | 10/7/26 (Wed) | Thu 2026-10-08 (Class 8) |
| Project 3: Your Field, With AI | 10/21/26 (Wed) | Thu 2026-10-22 (Class 12) |
| Capstone: Your Own Agent | 11/18/26 (Wed) | Thu 2026-11-19 (Class 20) |
| Professional Practice | 11/18/26 (Wed) | Thu 2026-11-19 (Class 20) |

### ANIM223 due dates
All five grading dates match a class meeting in the ANIM223 syllabus. No mismatches.

### Every NEEDS DATE row
- AI101: Study Trip 1 ("TBD and will announce on BB").
- AI101: Extra Help Session 1, 2, 3, 4 (Fridays, dates on BB).
- AI101: Office Hours ("TBD").
- AI101: Midterm Conference(s).
- ANIM223: Acquire the textbook & prepare for Class One ("beginning of the quarter", no start date given).
- ANIM223: the team discord and topic choice "over the weekend" after Class 14.
- ANIM223: Office Hours, Fridays 9am to 11 am (no start or end date).
- ANIM223: Midterm Conference(s).

### Other things to check
1. **AI101 "Your Agent Brief."** Confirmed by you: Tue 2026-09-15.
2. **ANIM223 Assignment 4 timing.** Launch says "Due by start of Class 19." The Class 19 entry says "final submission of all slides is by the end of Class 19." Same day (2026-11-17), different time.
3. **ANIM223 Assignment 3 readings.** It covers "chapters 12 thru 24." The schedule only assigns readings through Chapter 22.
4. **ANIM223 Class 15 reading.** The PDF puts Classes 15 and 16 side by side. I put "Chapters 16, 17, & 18" under Class 15.
5. **Names that differ inside ANIM223.** Grading table says "Midterm Test" and "Final Test." The schedule says "Assignment 2" and "Assignment 5." I kept the grading table wording and noted the other in Notes.
6. **AI101 Professional Practice.** Weight is written as "15" with no % sign. Copied as written.
7. **Same-day items inside AI101.** Capstone and Professional Practice both say 11/18/26. Just flagging. I'm not ranking them.

## Things you did not ask for (flagged)
- Class meetings, readings, launch dates, study trips, extra help sessions and office hours are in the table. Your decision-note says you keep these.
- Three ANIM223 optional events (AnimationFest, Savannah Film Festival, Digital Presence talk). The syllabus lists them as "Suggested." No year is printed. The weekdays only fit 2026.
- Midterm Conference(s) rows for both courses.
- Course evaluations "during Weeks 8, 9, and 10" appear in both syllabi. They are SCAD-wide, not course items, and the week boundaries are not defined. I left them out of the table.
- ANIM223 asks for a volunteer to set up a Discord. It has no date. Left out.
- `input/Syllabi/` has a third file, `ANIM353-syllabus.md`. You named two files, so I ignored it.
- Syllabus print dates: AI101 shows 10/4/26, ANIM223 shows 9/8/26. Please confirm both are the latest versions.

## How I converted dates
"Class N" means the Nth entry in that same course's Class Meeting Dates list. For AI101 the Schedule of Classes dates are all one day earlier than the Class Meeting Dates, so I used the Class Meeting Dates, per `decision-note.md`. I used the decision note for AI101 class meetings only. I did not use it for ANIM223 or for grading due dates.

## Step 1 report
- Both PDFs are there. AI101.pdf has 13 pages. ANIM223.pdf has 26 pages.
- Each has a list of 20 class meeting dates.
- Step 1 is your check, not mine: latest versions, meeting dates present. Treating "Inputs are ready" as your start signal.

## Human check (your turn)
I stopped here. I did not run steps 3 to 5.
1. Pick three converted items per course. Check each against that syllabus.
2. Answer the five AI101 due-date questions above.
3. Fill the NEEDS DATE rows you can, or tell me they stay open.
4. Tell me when the dates are correct. Then I start step 3.

## Run log
- **What you asked:** Run the Project 2 workflow from `00-start-here.md` on AI101.pdf and ANIM223.pdf. Save everything in `outputs/agent-run.md`. Do not overwrite other files in `outputs/`.
- **What I did:** Step 1 check, then step 2 as `agents/date-extractor.md`. Wrote this one file. Left every other file in `outputs/` alone.
- **What changed:** No grading date moved. `decision-note.md` used for AI101 class meetings and the first-class-meeting brief only.
- **Keep / change / reject:** Pending. You decide after the human check.


---

# Step 3: Add events to the calendar

Built only from the Step 2 table above. Title format: `[Course] Type: exact item name`. Saved here, not in `outputs/calendar.md`, because you told me to keep everything in this file and not touch other files in `outputs/`.

## Step 3 report

- Events added: **71** (AI101 26, ANIM223 45). That matches the 71 dated rows in the Step 2 table.
- Changed: none. First build of this calendar.
- Not yet scheduled: **11**.
- Fixed events (step 3a) come first on each day: classes, the ANIM223 study trip, the ANIM223 extra help session, and the three optional ANIM223 events. Due dates (step 3b) come after them.
- No "no class" rows exist in either syllabus, so none were added.
- Recurring office hours were not added. ANIM223 is Fridays 9am to 11 am with no start or end date. AI101 is TBD.
- Reading, Launch and in-class team rows stay in, per your decision-note. "Launch" rows are launch dates, not due dates.
- Multi-day events show on their start date. The title says where they end.

## Calendar

### Week of Sep 14–Sep 20

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-09-15 | Tue | AI101 | [AI101] Class: Class 1: Set Up Your Practice |
| 2026-09-15 | Tue | ANIM223 | [ANIM223] Class: Class 1, Lecture: The Beginning |
| 2026-09-15 | Tue | AI101 | [AI101] Assignment: Your Agent Brief |
| 2026-09-15 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation - Chapters 1 &2 |
| 2026-09-15 | Tue | ANIM223 | [ANIM223] Launch: Launch Assignment 1: Unit 1 Paper |
| 2026-09-17 | Thu | AI101 | [AI101] Class: Class 2: Make Something |
| 2026-09-17 | Thu | ANIM223 | [ANIM223] Class: Class 2, Lecture: Innovation & Experimentation in the early Silent Era |

### Week of Sep 21–Sep 27

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-09-22 | Tue | AI101 | [AI101] Class: Class 3: See the Whole Room |
| 2026-09-22 | Tue | ANIM223 | [ANIM223] Class: Class 3, Lecture: Growth of the Animation Industry in the 1920's |
| 2026-09-22 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation - Chapters 3 & 4 |
| 2026-09-23 | Wed | ANIM223 | [ANIM223] Optional event: SCAD AnimationFest (runs through Fri 2026-09-25) |
| 2026-09-24 | Thu | AI101 | [AI101] Class: Class 4: Name the Trade |
| 2026-09-24 | Thu | ANIM223 | [ANIM223] Class: Class 4, Lecture: Animation Matures as an Art Form |
| 2026-09-24 | Thu | AI101 | [AI101] Project: Project 1: Make, Then Compare |
| 2026-09-24 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation - Chapter 5 & 6 |

### Week of Sep 28–Oct 4

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-09-29 | Tue | AI101 | [AI101] Class: Class 5: Name the Process |
| 2026-09-29 | Tue | ANIM223 | [ANIM223] Class: Class 5, Lecture: First Features and Better Storytelling with Improved Believability |
| 2026-10-01 | Thu | AI101 | [AI101] Class: Class 6: Verify Your Sources |
| 2026-10-01 | Thu | ANIM223 | [ANIM223] Class: Class 6, Lecture: Warner Bros. |
| 2026-10-01 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 7 & 8 |

### Week of Oct 5–Oct 11

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-06 | Tue | AI101 | [AI101] Class: Class 7: Build a Pipeline |
| 2026-10-06 | Tue | ANIM223 | [ANIM223] Class: Class 7, Lecture: MGM and other Hollywood studios |
| 2026-10-08 | Thu | AI101 | [AI101] Class: Class 8: Take Feedback, Iterate |
| 2026-10-08 | Thu | ANIM223 | [ANIM223] Class: Class 8, Lecture: Wartime Animation |
| 2026-10-08 | Thu | AI101 | [AI101] Project: Project 2: Small Orchestration |
| 2026-10-08 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapter 9 |

### Week of Oct 12–Oct 18

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-13 | Tue | AI101 | [AI101] Class: Class 9: Disclosure and Position |
| 2026-10-13 | Tue | ANIM223 | [ANIM223] Class: Class 9, Lecture: Post-War and Midcentury Developments |
| 2026-10-13 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 10 & 11 |
| 2026-10-15 | Thu | AI101 | [AI101] Class: Class 10: Study Your Field |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Class: Class 10, Lecture: Rise of Stop Motion |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Extra help: An extra help session will be available on Thursday week 5, from 2 pm tho 4 pm in room 309. |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Launch: Launch Assignment 3: Unit 3 Paper |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Assignment: Assignment 1 - Written summaries of textbook chapters 1 thru 11 |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Test: Midterm Test |
| 2026-10-16 | Fri | ANIM223 | [ANIM223] Optional event: Digital Presence: Portfolios for Animators, VFX Artists, and More! |

### Week of Oct 19–Oct 25

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-20 | Tue | AI101 | [AI101] Class: Class 11: Build for Your Field |
| 2026-10-20 | Tue | ANIM223 | [ANIM223] Class: Class 11, Lecture: Animation Moves to the Small Screen as Live Action Did |
| 2026-10-20 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 12 & 13 |
| 2026-10-22 | Thu | AI101 | [AI101] Class: Class 12: Crit and Revise |
| 2026-10-22 | Thu | ANIM223 | [ANIM223] Class: Class 12, Lecture: Experimentation and Computers |
| 2026-10-22 | Thu | AI101 | [AI101] Project: Project 3: Your Field, With AI |
| 2026-10-24 | Sat | ANIM223 | [ANIM223] Optional event: SCAD Savannah Film Festival (runs through Sat 2026-10-31) |

### Week of Oct 26–Nov 1

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-27 | Tue | AI101 | [AI101] Class: Class 13: Define Your Agent |
| 2026-10-27 | Tue | ANIM223 | [ANIM223] Class: Class 13, Lecture: The Beginning of a Decline in Animated Theatrical Features |
| 2026-10-27 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 14 & 15 |
| 2026-10-29 | Thu | AI101 | [AI101] Class: Class 14: Assemble the Sources |
| 2026-10-29 | Thu | ANIM223 | [ANIM223] Class: Class 14, Lecture: Bluth, Bakshi, & Williams |
| 2026-10-29 | Thu | ANIM223 | [ANIM223] Launch: Launch Assignment 4 Team Presentation Project |

### Week of Nov 2–Nov 8

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-11-03 | Tue | AI101 | [AI101] Class: Class 15: Build and Test |
| 2026-11-03 | Tue | ANIM223 | [ANIM223] Class: Class 15, Lecture: Animation Festivals & Short Films |
| 2026-11-03 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 16, 17, & 18 |
| 2026-11-05 | Thu | AI101 | [AI101] Class: Class 16: Find the Failures |
| 2026-11-05 | Thu | ANIM223 | [ANIM223] Class: Class 16, Lecture: Animation in Canada |
| 2026-11-07 | Sat | ANIM223 | [ANIM223] Study trip: Jen Library Visit to view a selection of works from the Don Bluth Animation Production Collection from 10 am to 12 pm. |

### Week of Nov 9–Nov 15

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-11-10 | Tue | AI101 | [AI101] Class: Class 17: Revise |
| 2026-11-10 | Tue | ANIM223 | [ANIM223] Class: Class 17, Lecture: The Disney Renaissance |
| 2026-11-10 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 19 & 20 |
| 2026-11-10 | Tue | ANIM223 | [ANIM223] Event: Presentation Team Discussions - Assignment 4 |
| 2026-11-12 | Thu | AI101 | [AI101] Class: Class 18: Confirm the Difference |
| 2026-11-12 | Thu | ANIM223 | [ANIM223] Class: Class 18, Lecture: Emergence of Electronic Games & 3D Experimentation |
| 2026-11-12 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 21 & 22 |

### Week of Nov 16–Nov 22

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-11-17 | Tue | AI101 | [AI101] Class: Class 19: Demo and Defend |
| 2026-11-17 | Tue | ANIM223 | [ANIM223] Class: Class 19, Lecture: Japanese Animation |
| 2026-11-17 | Tue | ANIM223 | [ANIM223] Assignment: Assignment 3 -Written summaries of textbook chapters 12 thru 24 |
| 2026-11-17 | Tue | ANIM223 | [ANIM223] Project: Assignment 4 - Team Presentation Project |
| 2026-11-19 | Thu | AI101 | [AI101] Class: Class 20: Reflect and Carry Forward |
| 2026-11-19 | Thu | ANIM223 | [ANIM223] Class: Class 20, Lecture: Technology and Entertainment |
| 2026-11-19 | Thu | AI101 | [AI101] Project: Capstone: Your Own Agent |
| 2026-11-19 | Thu | AI101 | [AI101] Graded item: Professional Practice |
| 2026-11-19 | Thu | ANIM223 | [ANIM223] Test: Final Test |

## Not yet scheduled

| Course | Item | Why |
|---|---|---|
| AI101 | Study Trip 1 | Syllabus says TBD, announced on BB |
| AI101 | Extra Help Session 1 | Fridays, date and time announced on BB |
| AI101 | Extra Help Session 2 | Fridays, date and time announced on BB |
| AI101 | Extra Help Session 3 | Fridays, date and time announced on BB |
| AI101 | Extra Help Session 4 | Fridays, date and time announced on BB |
| AI101 | Office Hours | TBD |
| AI101 | Midterm Conference(s) | No date given |
| ANIM223 | Acquire the textbook & prepare for Class One | Syllabus never gives the quarter start date. Class 1 is Tue 2026-09-15. Not chosen for you. |
| ANIM223 | Over the weekend teams will establish a team discord, discuss and determine their 1st and 2nd choice of topic. | Weekend after Class 14 (Thu 2026-10-29) is not named with a date. Not chosen for you. |
| ANIM223 | Office Hours: Fridays from 9am to 11 am | Weekly, Fridays. Syllabus gives no start or end date, so I did not build a repeating event. |
| ANIM223 | Midterm Conference(s) | No date given |

## Human check (your turn)

Compare the dated count in the Step 2 table (71) with the events above (71). They match on my side. Count them yourself. If they don't match, tell me and I stop and find the gap.

I stopped here. I did not run step 4.

## Run log (step 3 addition)

- **What you asked:** Use class meeting dates for the five AI101 due dates, Agent Brief on 9/15 is correct, dates are right, continue to step 3.
- **What changed:** Five AI101 grading rows moved from NEEDS DATE to their class meeting dates (your decision). Step 3 calendar added to this file. No other file touched.
- **Keep / change / reject:** Pending your step 3 check.


---

# Step 4: Check for overlapping due dates

Built from the Step 3 calendar above. Saved here, not in `outputs/overlaps.md`, because that file already exists and you said not to touch other files in `outputs/`. I only flag. I don't move anything and I don't rank anything.

What counts as "due": assignments, projects, and tests (the graded items and the AI101 Agent Brief). Launch rows, readings, classes, trips and optional events are not due items.

## Overlaps

| Dates | Items (course + exact name) | Why it is flagged |
|---|---|---|
| Thu 2026-11-19 | AI101: Capstone: Your Own Agent; AI101: Professional Practice; ANIM223: Final Test | Same day |
| Mon 2026-11-16 to Sun 2026-11-22 | ANIM223: Assignment 3 -Written summaries of textbook chapters 12 thru 24 (Tue 11-17); ANIM223: Assignment 4 - Team Presentation Project (Tue 11-17); AI101: Capstone: Your Own Agent (Thu 11-19); AI101: Professional Practice (Thu 11-19); ANIM223: Final Test (Thu 11-19) | Heavy week (5 due items across both courses) |

**Overlaps found: 2 flags.** Both sit in the same stretch, Nov 16 to Nov 22. One is a same-day flag. One is a heavy-week flag.

## Checked and not flagged

- **Two tests in one week:** none. AI101 has no tests.
- **Thu 2026-10-15:** ANIM223 Assignment 1 and Midterm Test are both due. That is one course, so it isn't a cross-course overlap. Only 2 due items that week, under the 3-item bar. Just so you know.
- **Every other week:** 0 or 1 due items.

| Week (Mon to Sun) | Due items |
|---|---|
| Sep 14 to Sep 20 | 1 (AI101 Your Agent Brief) |
| Sep 21 to Sep 27 | 1 (AI101 Project 1) |
| Oct 5 to Oct 11 | 1 (AI101 Project 2) |
| Oct 12 to Oct 18 | 2 (ANIM223 Assignment 1, Midterm Test) |
| Oct 19 to Oct 25 | 1 (AI101 Project 3) |
| Nov 16 to Nov 22 | 5 (flagged above) |

## Heads up on limits

- Everything graded has a date now, so no graded item is missing from this check. The 11 NEEDS DATE rows are not due items, so they can't cause an overlap yet.
- The AI101 dates for Capstone and Professional Practice are the class meeting date you chose in step 2. The syllabus wrote 11/18/26 for both. If that changes, the 11/19 same-day flag changes too. The heavy week stays heavy either way.

## Human check (your turn)

Scan the three busiest weeks in the calendar yourself. If any is missing from the table above, tell me and I run step 4 again. I stopped here. I did not run step 5.

## Run log (step 4 addition)

- **What you asked:** Counts match, 71 and 71. Continue to step 4.
- **What changed:** Overlap check added to this file. No dates changed. No other file touched.
- **Keep / change / reject:** Pending your step 4 check.


---

# Step 5: Weekly review (model prep only)

Today is Fri 2026-10-23. Window: **Fri 2026-10-23 through Thu 2026-11-05** (14 days). Pulled from the Step 3 calendar above. This step is your human check. I only prepare the list and then stop.

## Events in the next 14 days (12)

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-24 | Sat | ANIM223 | [ANIM223] Optional event: SCAD Savannah Film Festival (runs through Sat 2026-10-31) |
| 2026-10-27 | Tue | AI101 | [AI101] Class: Class 13: Define Your Agent |
| 2026-10-27 | Tue | ANIM223 | [ANIM223] Class: Class 13, Lecture: The Beginning of a Decline in Animated Theatrical Features |
| 2026-10-27 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 14 & 15 |
| 2026-10-29 | Thu | AI101 | [AI101] Class: Class 14: Assemble the Sources |
| 2026-10-29 | Thu | ANIM223 | [ANIM223] Class: Class 14, Lecture: Bluth, Bakshi, & Williams |
| 2026-10-29 | Thu | ANIM223 | [ANIM223] Launch: Launch Assignment 4 Team Presentation Project |
| 2026-11-03 | Tue | AI101 | [AI101] Class: Class 15: Build and Test |
| 2026-11-03 | Tue | ANIM223 | [ANIM223] Class: Class 15, Lecture: Animation Festivals & Short Films |
| 2026-11-03 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 16, 17, & 18 |
| 2026-11-05 | Thu | AI101 | [AI101] Class: Class 16: Find the Failures |
| 2026-11-05 | Thu | ANIM223 | [ANIM223] Class: Class 16, Lecture: Animation in Canada |

## Due items in this window

None. No assignment, project, or test is due between 10/23 and 11/05.

## Overlaps in this window

None. The only flags are Thu 2026-11-19 and the week of Nov 16 to Nov 22, both outside the window.

## Not on the calendar, but could land in this window

I did not place any of these. They are NEEDS DATE.
- AI101 Extra Help Sessions 1 to 4: Fridays, dates announced on BB. Fridays in the window are 10/23 and 10/30.
- AI101 Study Trip 1: TBD on BB.
- AI101 Office Hours: TBD.
- ANIM223 Office Hours: Fridays 9am to 11 am. Fridays in the window are 10/23 and 10/30.
- ANIM223 team discord and topic choice "over the weekend" after Class 14: the weekend after Thu 10/29.
- AI101 and ANIM223 Midterm Conference(s): no date.

## Worth a look when you check

- The ANIM223 Class 15 reading ("Chapters 16, 17, & 18", Tue 11/03) is the one I read off a side-by-side PDF layout. Check it against the syllabus.
- Savannah Film Festival is optional and runs 10/24 to 10/31. It sits across your 10/27 and 10/29 classes. I'm only noting it.
- Check announcements from the past week (course site, email). I can't see those. Anything there that changes a date is yours to log.

## Your part (not done by me)

1. Check each listed date against that course's syllabus and last week's announcements.
2. Write any corrections in `outputs/weekly-review.md` under today's date as `Course | Item | Old date | New date | Source`. If none, write "No changes."
3. Anything you can't confirm, mark unconfirmed and ask the instructor.
4. Overlaps: none in this window, so no plan needed yet. The Nov 16 to Nov 22 plan is yours when you want it.

I did not create `weekly-review.md`. That file is yours. I stopped here.

## Run log (step 5 addition)

- **What you asked:** Busiest weeks checked, Nov 16 to Nov 22 flagged correctly, start step 5.
- **What changed:** Step 5 prep added to this file. No dates changed. No other file touched.
- **Keep / change / reject:** Pending your weekly check.


---

# Final run log (2026-10-23)

Logged on your word. I did not open or edit `outputs/weekly-review.md`.

## Status
Steps 1 to 5 are done. The dated items on the calendar are **confirmed by you**: 71 dated items, 71 events. Step 5 weekly review: "No changes."

## Unconfirmed (you will ask the instructor)
All AI101:
1. Extra help on 10/30
2. Study trip
3. Midterm conference
4. Office hours

These stay out of the confirmed set until you hear back.

## What you asked, what changed, keep / change / reject

| Step | What you asked | What changed | Keep / change / reject |
|---|---|---|---|
| Start | Run the workflow on AI101.pdf and ANIM223.pdf. Save only to `agent-run.md`. Don't overwrite other files in `outputs/`. | Created `agent-run.md`. No other file in `outputs/` touched. | Keep |
| 2 | Extract dated items with the date-extractor agent. | 82 items: 66 dated, 16 NEEDS DATE. Five AI101 due dates held back because they fell on Wednesdays. | Keep (you checked 3 items per course, all matched) |
| 2 | Decision on the five AI101 due dates. | Moved to the class meeting dates: Project 1 9/24, Project 2 10/8, Project 3 10/22, Capstone 11/19, Professional Practice 11/19. | **Change** (your decision) |
| 2 | Confirm Agent Brief date. | Stays Tue 9/15. | Keep |
| 3 | Add events. | 71 events, 11 Not yet scheduled. Counts matched. | Keep |
| 4 | Check overlaps. | 2 flags: Thu 11/19 (same day) and Nov 16 to Nov 22 (heavy week). No ranking. | Keep (you checked the busiest weeks) |
| 5 | Prep the 14-day window (10/23 to 11/05). | 12 events, 0 due items, 0 overlaps. You wrote `weekly-review.md`: "No changes," 4 items unconfirmed. | Keep |

## Still open
- 11 NEEDS DATE rows, none placed on the calendar. AI101 (7): study trip, extra help sessions 1 to 4, office hours, midterm conference. ANIM223 (4): textbook "by the beginning of the quarter", team discord weekend, office hours, midterm conference.
- Overlap plan for Nov 16 to Nov 22. Yours to decide.
- ANIM223 Class 15 reading placement was read off a side-by-side PDF layout. You checked the window and found no changes.
- Extra rows you did not ask for (readings, launch dates, optional events, study trips, extra help, midterm conferences) are in the calendar. I did not ask this run whether you keep or reject them. Your `decision-note.md` kept them before.

## Files
- Written this run: `project-02/outputs/agent-run.md` only.
- Written by you: `project-02/outputs/weekly-review.md`. Not touched by me.

## Questions it asked me, and my answers

|       |                      |                                                                                                                                                                                                                                                                                    |                                                                                                                                                                                |
| ----- | -------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Steps | Step name            | Agent request                                                                                                                                                                                                                                                                      | My response                                                                                                                                                                    |
| 1     | Collect syllabi      | 1. Pick three converted items per course and check them against the syllabus.<br>2. Answer the five AI101 due-date questions.<br>3. Confirm the "Your Agent Brief" date. I used Tue 9/15 for "first class meeting."<br>4. Tell me when the dates are right.                        | “I checked three items per course and they match. Use the class meeting date for the five due dates. Agent Brief on 9/15 is correct. The dates are right; continue to step 3.” |
| 2     | Date extracted agent | 1)    Pick three converted items per course and check them against the syllabus.<br><br>2)    Answer the five AI101 due-date questions.<br><br>3)    Confirm the "Your Agent Brief" date. I used Tue 9/15 for "first class meeting."<br><br>4)    Tell me when the dates are right | “I checked three items per course and they match. Use the class meeting date for the five due dates. Agent Brief on 9/15 is correct. The dates are right; continue to step 3.” |
| 3     | Add events           | count the events against the 71 dated rows. If they don't match, tell me and I'll find the gap. I stopped before step 4 (overlaps).                                                                                                                                                | “Counts match: 71 dated rows, 71 events. Continue to step 4.”                                                                                                                  |
| 4     | Overlaps             | Look at the three busiest weeks yourself. If one is missing from the table, tell me and I'll rerun step 4. I stopped before step 5.                                                                                                                                                | Checked the busiest weeks. Nov 16–22 is flagged correctly; nothing missing. Start step 5                                                                                       |
| 5     | Weekly review        | - Check the listed dates against the syllabi and last week's announcements.<br>- Write corrections in outputs/weekly-review.md, or "No changes" if there are none. I didn't create that file.<br>- Mark anything you can't confirm as unconfirmed and ask the instructor.          | No date changes. Wrote outputs/weekly-review.md myself. Four AI101 items unconfirmed (extra help 10/30, study trip, midterm conference, office hours); asking instructor.      |