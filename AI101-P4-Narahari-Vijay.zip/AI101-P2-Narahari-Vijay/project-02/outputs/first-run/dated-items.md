# Dated items (Step 2)

Source: `input/Syllabi/AI101.pdf` (page footer dated 10/4/26) and `input/Syllabi/ANIM223.pdf` (page footer dated 9/8/26). No other source was used.

**Counts:** AI101 32 items (6 `NEEDS DATE`, 21 `DATE CONFLICT`). ANIM223 45 items (3 `NEEDS DATE`). Total 77. No `no class` days are marked in either syllabus.

## Read this first: the AI101 syllabus disagrees with itself

AI101's "Class Meeting Dates" list gives Class 1 as Tuesday 9/15/26 and Class 20 as Thursday 11/19/26. AI101's "Schedule of Classes" table gives Class 1 as 9/14/26 and Class 20 as 11/18/26. Every one of the 20 classes differs by one day. The list matches the stated Tuesday / Thursday meeting pattern. The table dates fall on Mondays and Wednesdays. The AI101 "Grading Opportunities" dates (9/23, 10/7, 10/21, 11/18) match the table, not the list.

Per the project rules I list both dates and pick neither. Rows marked `DATE CONFLICT` are affected. Their sort position uses the list date only so the file has an order. The ANIM223 syllabus has no such problem: its schedule table Date column is blank, and its Class Meeting Dates list is the only class date source.

## Table

| Course | Item (exact syllabus wording) | Type | As written | Calendar date | Notes |
|---|---|---|---|---|---|
| AI101 | Class 1: Set Up Your Practice | class | Class 1 | DATE CONFLICT: Tue 2026-09-15 (Class Meeting Dates list) vs Mon 2026-09-14 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| AI101 | Your Agent Brief | assignment | By the first class meeting. | DATE CONFLICT: Tue 2026-09-15 (Class Meeting Dates list) vs Mon 2026-09-14 (Schedule of Classes table) | Pre-quarter Assignment. Class 1 is the first class meeting. Sorted by list date only. |
| ANIM223 | Lecture: The Beginning | class | Class 1 | Tue 2026-09-15 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list. Also lists Classroom Activity: Student Introductions. |
| ANIM223 | Reading: A New History of Animation - Chapters 1 &2 | reading | Class 1 | Tue 2026-09-15 | Listed under this class; syllabus gives no separate due time. |
| ANIM223 | Launch Assignment 1: Unit 1 Paper | assignment | Class 1 | Tue 2026-09-15 | Launch only. Due dates are on the DUE rows below. Named "Unit 1 Paper" here and "Written summaries of textbook chapters 1 thru 11" under Grading Opportunities. |
| AI101 | Class 2: Make Something | class | Class 2 | DATE CONFLICT: Thu 2026-09-17 (Class Meeting Dates list) vs Wed 2026-09-16 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Innovation & Experimentation in the early Silent Era | class | Class 2 | Thu 2026-09-17 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| AI101 | Class 3: See the Whole Room | class | Class 3 | DATE CONFLICT: Tue 2026-09-22 (Class Meeting Dates list) vs Mon 2026-09-21 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Growth of the Animation Industry in the 1920's | class | Class 3 | Tue 2026-09-22 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Reading: A New History of Animation - Chapters 3 & 4 | reading | Class 3 | Tue 2026-09-22 | Listed under this class; syllabus gives no separate due time. |
| AI101 | Project 1: Make, Then Compare | project | 9/23/26 | Wed 2026-09-23 | Grading Opportunities date, weight 15%. This date equals the Schedule of Classes table date for Class 4 (Wed 2026-09-23); the Class Meeting Dates list gives Thu 2026-09-24 for Class 4. Wed 2026-09-23 is not a Tue/Thu day. Not resolved. |
| AI101 | Class 4: Name the Trade | class | Class 4 | DATE CONFLICT: Thu 2026-09-24 (Class Meeting Dates list) vs Wed 2026-09-23 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Animation Matures as an Art Form | class | Class 4 | Thu 2026-09-24 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Reading: A New History of Animation - Chapter 5 & 6 | reading | Class 4 | Thu 2026-09-24 | Listed under this class; syllabus gives no separate due time. |
| AI101 | Class 5: Name the Process | class | Class 5 | DATE CONFLICT: Tue 2026-09-29 (Class Meeting Dates list) vs Mon 2026-09-28 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: First Features and Better Storytelling with Improved Believability | class | Class 5 | Tue 2026-09-29 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| AI101 | Class 6: Verify Your Sources | class | Class 6 | DATE CONFLICT: Thu 2026-10-01 (Class Meeting Dates list) vs Wed 2026-09-30 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Warner Bros. | class | Class 6 | Thu 2026-10-01 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Reading: A New History of Animation, Chapters 7 & 8 | reading | Class 6 | Thu 2026-10-01 | Listed under this class; syllabus gives no separate due time. |
| AI101 | Class 7: Build a Pipeline | class | Class 7 | DATE CONFLICT: Tue 2026-10-06 (Class Meeting Dates list) vs Mon 2026-10-05 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: MGM and other Hollywood studios | class | Class 7 | Tue 2026-10-06 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| AI101 | Project 2: Small Orchestration | project | 10/7/26 | Wed 2026-10-07 | Grading Opportunities date, weight 20%. This date equals the Schedule of Classes table date for Class 8 (Wed 2026-10-07); the Class Meeting Dates list gives Thu 2026-10-08 for Class 8. Wed 2026-10-07 is not a Tue/Thu day. Not resolved. |
| AI101 | Class 8: Take Feedback, Iterate | class | Class 8 | DATE CONFLICT: Thu 2026-10-08 (Class Meeting Dates list) vs Wed 2026-10-07 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Wartime Animation | class | Class 8 | Thu 2026-10-08 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Reading: A New History of Animation, Chapter 9 | reading | Class 8 | Thu 2026-10-08 | Listed under this class; syllabus gives no separate due time. |
| AI101 | Class 9: Disclosure and Position | class | Class 9 | DATE CONFLICT: Tue 2026-10-13 (Class Meeting Dates list) vs Mon 2026-10-12 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Post-War and Midcentury Developments | class | Class 9 | Tue 2026-10-13 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Reading: A New History of Animation, Chapters 10 & 11 | reading | Class 9 | Tue 2026-10-13 | Listed under this class; syllabus gives no separate due time. |
| AI101 | Class 10: Study Your Field | class | Class 10 | DATE CONFLICT: Thu 2026-10-15 (Class Meeting Dates list) vs Wed 2026-10-14 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Rise of Stop Motion | class | Class 10 | Thu 2026-10-15 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list. Class also lists DUE: Assignment 1 and DUE: Assignment 2 - Midterm Test. |
| ANIM223 | DUE: Assignment 1 - Submit remaining textbook summaries of chapters 1 thru 11. | assignment | Class 10 | Thu 2026-10-15 | Grading Opportunities row 1 gives 10/15/26 (matches). |
| ANIM223 | DUE: Assignment 2 - Midterm Test - Multiple choice and short answer - In Class Only | test | Class 10 | Thu 2026-10-15 | Grading Opportunities row 2 gives 10/15/26 (matches). "taken in class only today Class 10". |
| ANIM223 | Launch Assignment 3: Unit 3 Paper | assignment | Class 10 | Thu 2026-10-15 | Launch row says "Due by the beginning of Class 19". |
| ANIM223 | Extra Help Session 1 | class | 10/15/26: "Thursday week 5, from 2 pm tho 4 pm in room 309" | Thu 2026-10-15 | Date given directly. Same day as Class 10 (Midterm Test, Assignment 1 due). Type is nearest fit. Syllabus does not list week dates, so "week 5" was not converted. |
| AI101 | Class 11: Build for Your Field | class | Class 11 | DATE CONFLICT: Tue 2026-10-20 (Class Meeting Dates list) vs Mon 2026-10-19 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Animation Moves to the Small Screen as Live Action Did | class | Class 11 | Tue 2026-10-20 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Reading: A New History of Animation, Chapters 12 & 13 | reading | Class 11 | Tue 2026-10-20 | Listed under this class; syllabus gives no separate due time. |
| AI101 | Project 3: Your Field, With AI | project | 10/21/26 | Wed 2026-10-21 | Grading Opportunities date, weight 20%. This date equals the Schedule of Classes table date for Class 12 (Wed 2026-10-21); the Class Meeting Dates list gives Thu 2026-10-22 for Class 12. Wed 2026-10-21 is not a Tue/Thu day. Not resolved. |
| AI101 | Class 12: Crit and Revise | class | Class 12 | DATE CONFLICT: Thu 2026-10-22 (Class Meeting Dates list) vs Wed 2026-10-21 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Experimentation and Computers | class | Class 12 | Thu 2026-10-22 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| AI101 | Class 13: Define Your Agent | class | Class 13 | DATE CONFLICT: Tue 2026-10-27 (Class Meeting Dates list) vs Mon 2026-10-26 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: The Beginning of a Decline in Animated Theatrical Features | class | Class 13 | Tue 2026-10-27 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Reading: A New History of Animation, Chapters 14 & 15 | reading | Class 13 | Tue 2026-10-27 | Listed under this class; syllabus gives no separate due time. |
| AI101 | Class 14: Assemble the Sources | class | Class 14 | DATE CONFLICT: Thu 2026-10-29 (Class Meeting Dates list) vs Wed 2026-10-28 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Bluth, Bakshi, & Williams | class | Class 14 | Thu 2026-10-29 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Launch Assignment 4 Team Presentation Project - All are Due by start of Class 19 | project | Class 14; due: start of Class 19 | Thu 2026-10-29 | Class 19 row says final submission is "by the end of Class 19". Start vs end of Class 19 disagree within the syllabus. Not resolved. Weight 25%. |
| AI101 | Class 15: Build and Test | class | Class 15 | DATE CONFLICT: Tue 2026-11-03 (Class Meeting Dates list) vs Mon 2026-11-02 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Animation Festivals & Short Films | class | Class 15 | Tue 2026-11-03 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Reading: A New History of Animation, Chapters 16, 17, & 18 | reading | Class 15 | Tue 2026-11-03 | Listed under this class; syllabus gives no separate due time. |
| AI101 | Class 16: Find the Failures | class | Class 16 | DATE CONFLICT: Thu 2026-11-05 (Class Meeting Dates list) vs Wed 2026-11-04 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Animation in Canada | class | Class 16 | Thu 2026-11-05 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Study Trip 1: Jen Library | class | 11/7/26 | Sat 2026-11-07 | Visit to view a selection of works from the Don Bluth Animation Production Collection, 10 am to 12 pm. Type is nearest fit. |
| AI101 | Class 17: Revise | class | Class 17 | DATE CONFLICT: Tue 2026-11-10 (Class Meeting Dates list) vs Mon 2026-11-09 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: The Disney Renaissance | class | Class 17 | Tue 2026-11-10 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list. Class also lists Presentation Team Discussions - Assignment 4. |
| ANIM223 | Reading: A New History of Animation, Chapters 19 & 20 | reading | Class 17 | Tue 2026-11-10 | Listed under this class; syllabus gives no separate due time. |
| ANIM223 | Presentation Team Discussions - Assignment 4: | project | Class 17 | Tue 2026-11-10 | In-class team time for Assignment 4. |
| AI101 | Class 18: Confirm the Difference | class | Class 18 | DATE CONFLICT: Thu 2026-11-12 (Class Meeting Dates list) vs Wed 2026-11-11 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Emergence of Electronic Games & 3D Experimentation | class | Class 18 | Thu 2026-11-12 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.  |
| ANIM223 | Reading: A New History of Animation, Chapters 21 & 22 | reading | Class 18 | Thu 2026-11-12 | Listed under this class; syllabus gives no separate due time. |
| AI101 | Class 19: Demo and Defend | class | Class 19 | DATE CONFLICT: Tue 2026-11-17 (Class Meeting Dates list) vs Mon 2026-11-16 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Japanese Animation | class | Class 19 | Tue 2026-11-17 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list. Class also lists DUE: Assignment 3 and DUE: Assignment 4. |
| ANIM223 | DUE: Assignment 3 - Submit remaining textbook summaries of chapters 12 thru 24. | assignment | Class 19; also "Due by the beginning of Class 19" (Class 10) | Tue 2026-11-17 | Grading Opportunities row 3 gives 11/17/26 (matches). Chapters 23 and 24 are not assigned as a Reading in any class. |
| ANIM223 | DUE: Assignment 4 - Team Presentation Project | project | Class 19; "The final submission of all slides is by the end of Class 19" | Tue 2026-11-17 | Grading Opportunities row 4 gives 11/17/26 (matches). Class 14 launch says "start of Class 19". Not resolved. |
| AI101 | Capstone: Your Own Agent | project | 11/18/26 | Wed 2026-11-18 | Grading Opportunities date, weight 30%. This date equals the Schedule of Classes table date for Class 20 (Wed 2026-11-18); the Class Meeting Dates list gives Thu 2026-11-19 for Class 20. Wed 2026-11-18 is not a Tue/Thu day. Not resolved. |
| AI101 | Professional Practice | assignment | 11/18/26 | Wed 2026-11-18 | Grading Opportunities date, weight 15. This date equals the Schedule of Classes table date for Class 20 (Wed 2026-11-18); the Class Meeting Dates list gives Thu 2026-11-19 for Class 20. Wed 2026-11-18 is not a Tue/Thu day. Not resolved. |
| AI101 | Class 20: Reflect and Carry Forward | class | Class 20 | DATE CONFLICT: Thu 2026-11-19 (Class Meeting Dates list) vs Wed 2026-11-18 (Schedule of Classes table) | Sorted by the Class Meeting Dates list date only; neither date chosen. Syllabus says section meets Tuesday / Thursday. |
| ANIM223 | Lecture: Technology and Entertainment | class | Class 20 | Thu 2026-11-19 | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list. Class also lists DUE: Assignment 5 - Final Test. |
| ANIM223 | DUE: Assignment 5 - Final Test - Multiple choice and short answer - In Class Only | test | Class 20 | Thu 2026-11-19 | Grading Opportunities row 5 gives 11/19/26 (matches). |
| AI101 | Study Trip 1 | class | 1 TBD and will announce on BB | NEEDS DATE | Study (Field) Trips table. Type is nearest fit; not a class meeting. |
| AI101 | Extra Help Session 1 | class | 1: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Extra Help Session 2 | class | 2: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Extra Help Session 4 | class | 4: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Extra Help Session 3 | class | 3: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Midterm Conference(s) | class | scheduled outside of class time with the professor | NEEDS DATE | Standard policy text; no date given. Type is nearest fit; not a test or class meeting. |
| ANIM223 | Acquire the textbook & prepare for Class One | assignment | by the beginning of the quarter; "prepare for Class One" | NEEDS DATE | Pre-quarter Assignment. Syllabus gives no quarter start date. Class One is listed as Tue 2026-09-15 but the textbook deadline is worded as "beginning of the quarter". Also asks for a Discord volunteer and Blackboard review, no dates. |
| ANIM223 | Over the weekend teams will establish a team discord, discuss and determine their 1st and 2nd choice of topic. | assignment | Over the weekend (listed under Class 14) | NEEDS DATE | No weekend date given. |
| ANIM223 | Midterm Conference(s) | class | scheduled outside of class time with the professor | NEEDS DATE | Standard policy text; no date given. Type is nearest fit; not a test or class meeting. |

## Date references found but not entered as items

These have no type that fits (class / no class / reading / assignment / project / test) and are not syllabus-assigned work. I did not guess dates for them.

- AI101: "free GitHub account (set up in class, Week 2)". The syllabus lists no week dates, so "Week 2" was not converted.
- AI101 and ANIM223: "Course evaluations ... during Weeks 8, 9, and 10 through MySCAD". No week dates listed, not converted.
- ANIM223 Suggested Extended Learning Opportunities (optional, dated as written, no year given): SCAD AnimationFest, Wednesday, Sept. 23 - Friday, Sept. 25 (Atlanta); Digital Presence: Portfolios for Animators, VFX Artists, and More!, Friday, Oct. 16, 3pm - 4pm; SCAD Savannah Film Festival, Saturday, Oct. 24 - Saturday, Oct. 31.
- ANIM223 office hours: Fridays from 9am to 11 am (recurring, no dates). AI101 office hours: TBD.

## Other things to check

- ANIM223: Class 14 launch says Assignment 4 is due by the start of Class 19. The Class 19 row says the final submission of slides is by the end of Class 19. Both are listed; neither chosen.
- ANIM223: Assignment 3 covers chapters 12 thru 24, but readings are only assigned through chapter 22. Chapters 23 and 24 appear in no class.
- ANIM223: Assignment 1 is named "Unit 1 Paper" at launch, and "Written summaries of textbook chapters 1 thru 11" in Grading Opportunities. Both names kept as written, on separate rows.
- ANIM223 Class 10 (Thu 2026-10-15) has the Midterm Test and Assignment 1 due, plus Extra Help Session 1 that afternoon. Flagged for step 4; not resolved here.
- The two PDFs were captured on different dates (ANIM223 on 9/8/26, AI101 on 10/4/26). Worth confirming ANIM223 is still the latest version.
