# Calendar (fresh-input run)

**Merged events: 100** (existing AI101/ANIM223 calendar plus ANIM353 additions). **ANIM353 additions: 41** (20 classes, 7 assignment deadlines, 2 study trips, 3 extra help sessions, 9 dated dailies checkpoints).

ANIM353 class numbers map to the dates listed under that syllabus's Class Meeting Dates. For Assignment 2: HORSE WALK, HORSE TROT, and HORSE GALLOP, the Class-based dates are used as instructed; the syllabus also has a combined Horse Locomotion grading date of 10/12/26.

## Week of Sep 14–Sep 20

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-09-14 | Mon | ANIM353 | [ANIM353] Class: Class 1 |
| 2026-09-15 | Tue | AI101 | [AI101] Assignment: Your Agent Brief |
| 2026-09-15 | Tue | AI101 | [AI101] Class: Class 1: Set Up Your Practice |
| 2026-09-15 | Tue | ANIM223 | [ANIM223] Assignment: Launch Assignment 1: Unit 1 Paper |
| 2026-09-15 | Tue | ANIM223 | [ANIM223] Class: Lecture: The Beginning |
| 2026-09-15 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation - Chapters 1 &2 |
| 2026-09-16 | Wed | ANIM353 | [ANIM353] Class: Class 2 |
| 2026-09-16 | Wed | ANIM353 | [ANIM353] Dailies: Submit your most recent progress to Syncsketch and put the link in Discord. |
| 2026-09-17 | Thu | AI101 | [AI101] Class: Class 2: Make Something |
| 2026-09-17 | Thu | ANIM223 | [ANIM223] Class: Lecture: Innovation & Experimentation in the early Silent Era |

## Week of Sep 21–Sep 27

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-09-21 | Mon | ANIM353 | [ANIM353] Assignment: Assignment 1: THE FLIGHTLESS BIRD |
| 2026-09-21 | Mon | ANIM353 | [ANIM353] Class: Class 3 |
| 2026-09-22 | Tue | AI101 | [AI101] Class: Class 3: See the Whole Room |
| 2026-09-22 | Tue | ANIM223 | [ANIM223] Class: Lecture: Growth of the Animation Industry in the 1920's |
| 2026-09-22 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation - Chapters 3 & 4 |
| 2026-09-23 | Wed | ANIM353 | [ANIM353] Class: Class 4 |
| 2026-09-23 | Wed | ANIM353 | [ANIM353] Dailies: Submit your most recent progress to Syncsketch and put the link in Discord. |
| 2026-09-23 | Wed | ANIM353 | [ANIM353] Study Trip: Study Trip 2: SCAD ANIM FEST (description: Sep 23–25) |
| 2026-09-24 | Thu | AI101 | [AI101] Class: Class 4: Name the Trade |
| 2026-09-24 | Thu | AI101 | [AI101] Project: Project 1: Make, Then Compare |
| 2026-09-24 | Thu | ANIM223 | [ANIM223] Class: Lecture: Animation Matures as an Art Form |
| 2026-09-24 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation - Chapter 5 & 6 |

## Week of Sep 28–Oct 4

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-09-28 | Mon | ANIM353 | [ANIM353] Assignment: Assignment 2: HORSE WALK |
| 2026-09-28 | Mon | ANIM353 | [ANIM353] Class: Class 5 |
| 2026-09-29 | Tue | AI101 | [AI101] Class: Class 5: Name the Process |
| 2026-09-29 | Tue | ANIM223 | [ANIM223] Class: Lecture: First Features and Better Storytelling with Improved Believability |
| 2026-09-30 | Wed | ANIM353 | [ANIM353] Class: Class 6 |
| 2026-09-30 | Wed | ANIM353 | [ANIM353] Dailies: Submit your most recent progress to Syncsketch and put the link in Discord. |
| 2026-10-01 | Thu | AI101 | [AI101] Class: Class 6: Verify Your Sources |
| 2026-10-01 | Thu | ANIM223 | [ANIM223] Class: Lecture: Warner Bros. |
| 2026-10-01 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 7 & 8 |

## Week of Oct 5–Oct 11

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-05 | Mon | ANIM353 | [ANIM353] Assignment: Assignment 2: HORSE TROT |
| 2026-10-05 | Mon | ANIM353 | [ANIM353] Class: Class 7 |
| 2026-10-06 | Tue | AI101 | [AI101] Class: Class 7: Build a Pipeline |
| 2026-10-06 | Tue | ANIM223 | [ANIM223] Class: Lecture: MGM and other Hollywood studios |
| 2026-10-07 | Wed | ANIM353 | [ANIM353] Class: Class 8 |
| 2026-10-07 | Wed | ANIM353 | [ANIM353] Dailies: Submit your most recent progress to Syncsketch and put the link in Discord. |
| 2026-10-08 | Thu | AI101 | [AI101] Class: Class 8: Take Feedback, Iterate |
| 2026-10-08 | Thu | AI101 | [AI101] Project: Project 2: Small Orchestration |
| 2026-10-08 | Thu | ANIM223 | [ANIM223] Class: Lecture: Wartime Animation |
| 2026-10-08 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapter 9 |
| 2026-10-09 | Fri | ANIM353 | [ANIM353] Extra Help Session 1 (09:00 AM–11:00 AM, Monty 311) |

## Week of Oct 12–Oct 18

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-12 | Mon | ANIM353 | [ANIM353] Assignment: Assignment 2: HORSE GALLOP |
| 2026-10-12 | Mon | ANIM353 | [ANIM353] Class: Class 9 |
| 2026-10-13 | Tue | AI101 | [AI101] Class: Class 9: Disclosure and Position |
| 2026-10-13 | Tue | ANIM223 | [ANIM223] Class: Lecture: Post-War and Midcentury Developments |
| 2026-10-13 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 10 & 11 |
| 2026-10-14 | Wed | ANIM353 | [ANIM353] Class: Class 10 |
| 2026-10-14 | Wed | ANIM353 | [ANIM353] Dailies: Submit your most recent progress to Syncsketch and put the link in Discord. |
| 2026-10-15 | Thu | AI101 | [AI101] Class: Class 10: Study Your Field |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Assignment: DUE: Assignment 1 - Submit remaining textbook summaries of chapters 1 thru 11. |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Assignment: Launch Assignment 3: Unit 3 Paper |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Class: Extra Help Session 1 |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Class: Lecture: Rise of Stop Motion |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Test: DUE: Assignment 2 - Midterm Test - Multiple choice and short answer - In Class Only |
| 2026-10-16 | Fri | ANIM353 | [ANIM353] Study Trip: Study Trip 1: Oatland Island Wildlife Center (11:00 AM–3:00 PM) |

## Week of Oct 19–Oct 25

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-19 | Mon | ANIM353 | [ANIM353] Class: Class 11 |
| 2026-10-19 | Mon | ANIM353 | [ANIM353] Dailies: Submit your most recent progress to Syncsketch and put the link in Discord. |
| 2026-10-20 | Tue | AI101 | [AI101] Class: Class 11: Build for Your Field |
| 2026-10-20 | Tue | ANIM223 | [ANIM223] Class: Lecture: Animation Moves to the Small Screen as Live Action Did |
| 2026-10-20 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 12 & 13 |
| 2026-10-21 | Wed | ANIM353 | [ANIM353] Class: Class 12 |
| 2026-10-22 | Thu | AI101 | [AI101] Class: Class 12: Crit and Revise |
| 2026-10-22 | Thu | AI101 | [AI101] Project: Project 3: Your Field, With AI |
| 2026-10-22 | Thu | ANIM223 | [ANIM223] Class: Lecture: Experimentation and Computers |
| 2026-10-23 | Fri | ANIM353 | [ANIM353] Extra Help Session 2 (09:00 AM–11:00 AM, Monty 311) |

## Week of Oct 26–Nov 1

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-26 | Mon | ANIM353 | [ANIM353] Assignment: Assignment 3: BIRD IN FLIGHT |
| 2026-10-26 | Mon | ANIM353 | [ANIM353] Class: Class 13 |
| 2026-10-27 | Tue | AI101 | [AI101] Class: Class 13: Define Your Agent |
| 2026-10-27 | Tue | ANIM223 | [ANIM223] Class: Lecture: The Beginning of a Decline in Animated Theatrical Features |
| 2026-10-27 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 14 & 15 |
| 2026-10-28 | Wed | ANIM353 | [ANIM353] Class: Class 14 |
| 2026-10-29 | Thu | AI101 | [AI101] Class: Class 14: Assemble the Sources |
| 2026-10-29 | Thu | ANIM223 | [ANIM223] Class: Lecture: Bluth, Bakshi, & Williams |
| 2026-10-29 | Thu | ANIM223 | [ANIM223] Project: Launch Assignment 4 Team Presentation Project - All are Due by start of Class 19 |
| 2026-10-30 | Fri | ANIM353 | [ANIM353] Extra Help Session 3 (09:00 AM–10:00 AM, Monty 311) |

## Week of Nov 2–Nov 8

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-11-02 | Mon | ANIM353 | [ANIM353] Class: Class 15 |
| 2026-11-02 | Mon | ANIM353 | [ANIM353] Dailies: Submit your most recent progress to Syncsketch and put the link in Discord. |
| 2026-11-03 | Tue | AI101 | [AI101] Class: Class 15: Build and Test |
| 2026-11-03 | Tue | ANIM223 | [ANIM223] Class: Lecture: Animation Festivals & Short Films |
| 2026-11-03 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 16, 17, & 18 |
| 2026-11-04 | Wed | ANIM353 | [ANIM353] Assignment: Assignment 4: CREATURE LOCOMOTION |
| 2026-11-04 | Wed | ANIM353 | [ANIM353] Class: Class 16 |
| 2026-11-05 | Thu | AI101 | [AI101] Class: Class 16: Find the Failures |
| 2026-11-05 | Thu | ANIM223 | [ANIM223] Class: Lecture: Animation in Canada |
| 2026-11-07 | Sat | ANIM223 | [ANIM223] Class: Study Trip 1: Jen Library |

## Week of Nov 9–Nov 15

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-11-09 | Mon | ANIM353 | [ANIM353] Class: Class 17 |
| 2026-11-09 | Mon | ANIM353 | [ANIM353] Dailies: Submit your most recent progress to Syncsketch and put the link in Discord. |
| 2026-11-10 | Tue | AI101 | [AI101] Class: Class 17: Revise |
| 2026-11-10 | Tue | ANIM223 | [ANIM223] Class: Lecture: The Disney Renaissance |
| 2026-11-10 | Tue | ANIM223 | [ANIM223] Project: Presentation Team Discussions - Assignment 4: |
| 2026-11-10 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 19 & 20 |
| 2026-11-11 | Wed | ANIM353 | [ANIM353] Class: Class 18 |
| 2026-11-12 | Thu | AI101 | [AI101] Class: Class 18: Confirm the Difference |
| 2026-11-12 | Thu | ANIM223 | [ANIM223] Class: Lecture: Emergence of Electronic Games & 3D Experimentation |
| 2026-11-12 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 21 & 22 |

## Week of Nov 16–Nov 22

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-11-16 | Mon | ANIM353 | [ANIM353] Class: Class 19 |
| 2026-11-16 | Mon | ANIM353 | [ANIM353] Dailies: Submit your most recent progress to Syncsketch and put the link in Discord. |
| 2026-11-17 | Tue | AI101 | [AI101] Class: Class 19: Demo and Defend |
| 2026-11-17 | Tue | ANIM223 | [ANIM223] Assignment: DUE: Assignment 3 - Submit remaining textbook summaries of chapters 12 thru 24. |
| 2026-11-17 | Tue | ANIM223 | [ANIM223] Class: Lecture: Japanese Animation |
| 2026-11-17 | Tue | ANIM223 | [ANIM223] Project: DUE: Assignment 4 - Team Presentation Project |
| 2026-11-18 | Wed | ANIM353 | [ANIM353] Assignment: Assignment 5: CREATURE FEATURE |
| 2026-11-18 | Wed | ANIM353 | [ANIM353] Class: Class 20 |
| 2026-11-19 | Thu | AI101 | [AI101] Assignment: Professional Practice |
| 2026-11-19 | Thu | AI101 | [AI101] Class: Class 20: Reflect and Carry Forward |
| 2026-11-19 | Thu | AI101 | [AI101] Project: Capstone: Your Own Agent |
| 2026-11-19 | Thu | ANIM223 | [ANIM223] Class: Lecture: Technology and Entertainment |
| 2026-11-19 | Thu | ANIM223 | [ANIM223] Test: DUE: Assignment 5 - Final Test - Multiple choice and short answer - In Class Only |

## Not yet scheduled

| Course | Item | As written |
|---|---|---|
| ANIM353 | Watch the "Class Introduction Video" (in Blackboard) to prepare your files and programs. | Pre-quarter Assignment | No date stated. |
| ANIM353 | Read the Additional Course Information at the end of the syllabus. | Pre-quarter Assignment | No date stated. |
| ANIM353 | Watch Amazing Animal Moments from the BBC Earth documentary series. Scroll back and forth and analyze favorite moments of animal behavior. | Pre-quarter Assignment | No date stated. |
| ANIM353 | Watch Ostrich the Flightless Bird (documentary by ProArtnc and Beautiful Washington). Observe the ostrich's behavior and movements and capture key moments for the ostrich animation. | Pre-quarter Assignment | No date stated. |
| ANIM353 | Course Evaluations | Weeks 8, 9, and 10 | Availability window stated, but no exact dates. |
| ANIM353 | Professor office hours | M-TH 10:45-11:45PM | Recurring weekday time stated without a start/end date range; not expanded into dated calendar rows. |
| ANIM353 | Submit your most recent progress to Syncsketch and put the link in Discord. | Classes 2, 4, 6, 8, 10, 11, 15, 17, 19 | Checkpoint appears in those class sections; calendar meeting rows are included, but checkpoint was not split into separate timed events. |

## Existing recurring notes

- ANIM223 professor office hours: Fridays, 9 am to 11 am; syllabus gives no date range.
- AI101 professor office hours: TBD in syllabus.
- ANIM353 professor office hours: M-TH 10:45-11:45PM; syllabus gives no date range. Not expanded into dated entries.
- Weekly AI101, ANIM223, and ANIM353 class meetings appear as individual rows above.
