# ANIM353 dated items (fresh-input run)

Source: `project-02/input/Syllabi/ANIM353-syllabus.md`. Class references converted only with this syllabus's Class Meeting Dates list. Dates chosen for the three horse-cycle assignments follow Vijay's instruction.

| Course | Item (exact syllabus wording) | Type | As written | Calendar date | Notes |
|---|---|---|---|---|
| ANIM353 | Class 1 | class | Class 1 | 2026-09-14 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 2 | class | Class 2 | 2026-09-16 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 3 | class | Class 3 | 2026-09-21 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 4 | class | Class 4 | 2026-09-23 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 5 | class | Class 5 | 2026-09-28 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 6 | class | Class 6 | 2026-09-30 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 7 | class | Class 7 | 2026-10-05 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 8 | class | Class 8 | 2026-10-07 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 9 | class | Class 9 | 2026-10-12 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 10 | class | Class 10 | 2026-10-14 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 11 | class | Class 11 | 2026-10-19 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 12 | class | Class 12 | 2026-10-21 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 13 | class | Class 13 | 2026-10-26 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 14 | class | Class 14 | 2026-10-28 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 15 | class | Class 15 | 2026-11-02 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 16 | class | Class 16 | 2026-11-04 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 17 | class | Class 17 | 2026-11-09 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 18 | class | Class 18 | 2026-11-11 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 19 | class | Class 19 | 2026-11-16 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Class 20 | class | Class 20 | 2026-11-18 | Mapped by Class number to the ANIM353 Class Meeting Dates list. |
| ANIM353 | Assignment 1: THE FLIGHTLESS BIRD | assignment | Class 03 | 2026-09-21 | Explicit DUE in Class 3; matches Grading Opportunities 1 date 9/21/26. |
| ANIM353 | Assignment 2: HORSE WALK | assignment | Class 05 | 2026-09-28 | Explicit DUE in Class 5; date selected per your instruction. Grading Opportunities combines horse work on 10/12/26. |
| ANIM353 | Assignment 2: HORSE TROT | assignment | Class 07 | 2026-10-05 | Explicit DUE in Class 7; date selected per your instruction. Grading Opportunities combines horse work on 10/12/26. |
| ANIM353 | Assignment 2: HORSE GALLOP | assignment | Class 09 | 2026-10-12 | Explicit DUE in Class 9; date selected per your instruction. Grading Opportunities combines horse work on 10/12/26. |
| ANIM353 | Assignment 3: BIRD IN FLIGHT | assignment | Class 13 | 2026-10-26 | Explicit DUE in Class 13; matches Grading Opportunities 3 date 10/26/26. |
| ANIM353 | Assignment 4: CREATURE LOCOMOTION | assignment | Class 16 | 2026-11-04 | Explicit DUE in Class 16; matches Grading Opportunities 4 date 11/4/26. |
| ANIM353 | Assignment 5: CREATURE FEATURE | assignment | Class 20 | 2026-11-18 | Explicit DUE in Class 20; matches Grading Opportunities 5 date 11/18/26. |
| ANIM353 | Study Trip 1: Oatland Island Wildlife Center | event | 10/16/26 | 2026-10-16 | 11:00 AM–3:00 PM; meet at the Center; buses provided. |
| ANIM353 | Study Trip 2: SCAD ANIM FEST | event | 9/23/26; description says Wednesday, Sept. 23–Friday, Sept. 25 | 2026-09-23 | Source date is 9/23/26; description gives event span through 9/25/26. |
| ANIM353 | Extra Help Session 1 | event | 10/9/26 | 2026-10-09 | 09:00 AM–11:00 AM, Monty 311. |
| ANIM353 | Extra Help Session 2 | event | 10/23/26 | 2026-10-23 | 09:00 AM–11:00 AM, Monty 311. |
| ANIM353 | Extra Help Session 3 | event | 10/30/26 | 2026-10-30 | 09:00 AM–10:00 AM, Monty 311. |

| ANIM353 | Submit your most recent progress to Syncsketch and put the link in Discord. | checkpoint | Class 2 | 2026-09-16 | Dated by this syllabus's Class Meeting Dates; no submission time specified. |
| ANIM353 | Submit your most recent progress to Syncsketch and put the link in Discord. | checkpoint | Class 4 | 2026-09-23 | Dated by this syllabus's Class Meeting Dates; no submission time specified. |
| ANIM353 | Submit your most recent progress to Syncsketch and put the link in Discord. | checkpoint | Class 6 | 2026-09-30 | Dated by this syllabus's Class Meeting Dates; no submission time specified. |
| ANIM353 | Submit your most recent progress to Syncsketch and put the link in Discord. | checkpoint | Class 8 | 2026-10-07 | Dated by this syllabus's Class Meeting Dates; no submission time specified. |
| ANIM353 | Submit your most recent progress to Syncsketch and put the link in Discord. | checkpoint | Class 10 | 2026-10-14 | Dated by this syllabus's Class Meeting Dates; no submission time specified. |
| ANIM353 | Submit your most recent progress to Syncsketch and put the link in Discord. | checkpoint | Class 11 | 2026-10-19 | Dated by this syllabus's Class Meeting Dates; no submission time specified. |
| ANIM353 | Submit your most recent progress to Syncsketch and put the link in Discord. | checkpoint | Class 15 | 2026-11-02 | Dated by this syllabus's Class Meeting Dates; no submission time specified. |
| ANIM353 | Submit your most recent progress to Syncsketch and put the link in Discord. | checkpoint | Class 17 | 2026-11-09 | Dated by this syllabus's Class Meeting Dates; no submission time specified. |
| ANIM353 | Submit your most recent progress to Syncsketch and put the link in Discord. | checkpoint | Class 19 | 2026-11-16 | Dated by this syllabus's Class Meeting Dates; no submission time specified. |

## Not yet scheduled

| Course | Item | As written | Reason |
|---|---|---|---|
| ANIM353 | Watch the "Class Introduction Video" (in Blackboard) to prepare your files and programs. | Pre-quarter Assignment | No date stated. |
| ANIM353 | Read the Additional Course Information at the end of the syllabus. | Pre-quarter Assignment | No date stated. |
| ANIM353 | Watch Amazing Animal Moments from the BBC Earth documentary series. Scroll back and forth and analyze favorite moments of animal behavior. | Pre-quarter Assignment | No date stated. |
| ANIM353 | Watch Ostrich the Flightless Bird (documentary by ProArtnc and Beautiful Washington). Observe the ostrich's behavior and movements and capture key moments for the ostrich animation. | Pre-quarter Assignment | No date stated. |
| ANIM353 | Course Evaluations | Weeks 8, 9, and 10 | Availability window stated, but no exact dates. |
| ANIM353 | Professor office hours | M-TH 10:45-11:45PM | Recurring weekday time stated without a start/end date range; not expanded into dated calendar rows. |
