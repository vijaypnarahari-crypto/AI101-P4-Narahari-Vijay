# Overlaps (fresh-input run)

Built from the merged fresh-input calendar. Counted are Assignment, Project, and Test rows, excluding launch-only rows. Weeks run Monday through Sunday. **Flags found: 3.** These flags describe date concentration; they do not recommend an action.

| Dates | Items (course + exact name) | Why it is flagged |
|---|---|---|
| Thu 2026-11-19 | AI101: Professional Practice (2026-11-19)<br>AI101: Capstone: Your Own Agent (2026-11-19)<br>ANIM223: DUE: Assignment 5 - Final Test - Multiple choice and short answer - In Class Only (2026-11-19) | same date across courses |
| Mon 2026-10-12 to Sun 2026-10-18 | ANIM353: Assignment 2: HORSE GALLOP (2026-10-12)<br>ANIM223: DUE: Assignment 1 - Submit remaining textbook summaries of chapters 1 thru 11. (2026-10-15)<br>ANIM223: DUE: Assignment 2 - Midterm Test - Multiple choice and short answer - In Class Only (2026-10-15) | busy week (3 due items) |
| Mon 2026-11-16 to Sun 2026-11-22 | ANIM223: DUE: Assignment 3 - Submit remaining textbook summaries of chapters 12 thru 24. (2026-11-17)<br>ANIM223: DUE: Assignment 4 - Team Presentation Project (2026-11-17)<br>ANIM353: Assignment 5: CREATURE FEATURE (2026-11-18)<br>AI101: Professional Practice (2026-11-19)<br>AI101: Capstone: Your Own Agent (2026-11-19)<br>ANIM223: DUE: Assignment 5 - Final Test - Multiple choice and short answer - In Class Only (2026-11-19) | busy week (6 due items) |
