# Weekly Review: 10/23/26

Window: Fri 10/23 to Thu 11/5.
Checked against the AI101 and ANIM223 syllabi and last week's announcements
(Blackboard and email).

## Corrections
No changes.

## Unconfirmed (ask instructor)
| Course | Item               | What the syllabus says   | Status                                  |
| ------ | ------------------ | ------------------------ | --------------------------------------- |
| AI101  | Extra help session | Fridays, announced on BB | Unconfirmed: is there one on Fri 10/30? |
| AI101  | Study trip         | TBD, announced on BB     | Unconfirmed                             |
| AI101  | Midterm conference | Scheduled with professor | Unconfirmed                             |
| AI101  | Office hours       | TBD                      | Unconfirmed                             |

# Weekly Review: 10/24/26

Window: Sat 10/24 through Sat 11/7 (next 14 days from this review date). This draft is based on the three syllabi; it has not been checked against Blackboard, email, or new announcements. Please compare it against those sources and add corrections here.

## Calendar items to review

- **Sun 10/25:** 2-hour study block — ANIM353 Assignment 3: BIRD IN FLIGHT.
- **Mon 10/26:** ANIM353 Class 13; Assignment 3: BIRD IN FLIGHT due.
- **Tue 10/27:** AI101 Class 13; ANIM223 Class 13; ANIM223 reading, Chapters 14 & 15.
- **Wed 10/28:** ANIM353 Class 14.
- **Thu 10/29:** AI101 Class 14; ANIM223 Class 14.
- **Mon 11/2:** ANIM353 Class 15.
- **Tue 11/3:** AI101 Class 15; ANIM223 Class 15; reading, Chapters 16, 17 & 18; 2-hour study block — ANIM353 Assignment 4: CREATURE LOCOMOTION.
- **Wed 11/4:** ANIM353 Class 16; Assignment 4: CREATURE LOCOMOTION due.
- **Thu 11/5:** AI101 Class 16; ANIM223 Class 16; reading, Chapters 19 & 20.
- **Sat 11/7:** ANIM223 Jen Library visit, 10 am–12 pm.

## Corrections

No changes. Vijay checked and reports no new changes for this review window.
