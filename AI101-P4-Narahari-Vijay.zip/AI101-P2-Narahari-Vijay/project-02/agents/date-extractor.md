# Date extractor agent

## Role

Turns each syllabus into one list of calendar entries, using only that course's own schedule as listed in the syllabus.

## The step it replaces

**Step file replaced:** `02-extract-dated-items.md`

**Why this step suits an agent:** Both the syllabus can use the agent because we can repeat it on both of syllabi, and can check it against the syllabus' schedule. Moreover, whenever there is a confusion, the agent says NEEDS DATE instead of guessing a date on its own and it never moves a grading opportunity date without asking me first. 

## Inputs it may read

The files it needs to read are AI101.pdf, ANIM223.pdf, and decision-note.md. The path to the files is shown below.

- project-02/input/Syllabi/AI101.pdf`
- project-02/input/Syllabi/ANIM223.pdf
- project-02/decision-note.md (only for the AI101 class-date conflict; never for due dates)

## What it does
1. Reads each syllabus entirely from top to bottom, including tables, schedules, extracts every assignment, project, quiz, test, and event, etc.
2. Records each item's date exactly as written ("Class 7", "Week 3")
3. Converts relative dates to calendar dates using only that syllabus's class meeting dates: For example, "Class 3" is meeting 3; "Week 5" is the named day in week 5, or the first class meeting of week 3 i no day is named.
4. Writes `NEEDS DATE` for any item it can't match to a date or if there is any confusion.
5. Copies due dates from the Grading Opportunities table exactly as written.
6. Saves one table to `project-02/outputs/agent-run.md` with the columns Course, Item (exact syllabus wording), Type, As written, Calendar date, Notes. Sorts by date, with NEEDS DATE rows at the bottom.
7. Reports how many items for AI101, how many for ANIM223, and how many are NEEDS DATE.

## What it may not decide

- A date the syllabus doesn't give. It writes NEEDS DATE and asks me.
- Moving a grading due date. If a due date doesn't match the class meeting date, it lists both and asks me. This overrides decision-note.md for due dates, because I don't want to be late on a graded item.
- Besides dates, such as which assignment has higher priority has an overlap of the due dates.

## Human check

After saving the table, the agent stops and shows me the item counts, every NEEDS DATE row, and every due date that doesn't match a class meeting date. I pick three converted items per course and check them against that syllabus's schedule, and I answer each due-date question. If any date is wrong, the agent fixes it and runs again. It doesn't move on to step 3 until I say the dates are correct.