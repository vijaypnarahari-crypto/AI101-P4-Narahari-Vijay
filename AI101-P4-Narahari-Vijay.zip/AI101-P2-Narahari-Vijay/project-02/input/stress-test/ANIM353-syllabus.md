# ANIM 353 3D Character Animation: Creatures and Quadrupeds

- Section: 01
- CRN: 11811
- Room: MONTGO 321
- Meets: Monday / Wednesday 5:00 PM - 7:30 PM
- Source: https://scad.simplesyllabus.com/en-US/doc/xtl5oky8m/Fall-2026-ANIM-SAV-353-11811-3D-Character-Animation:-Creatures-and-Quadrupeds?mode=view (printed 10/20/26)

## Instructor Information

- Professor: Tiffanni Blevins
- Email: tblevins@scad.edu
- Phone: 912-525-8581
- Office Location: Montgomery Hall, 418 A
- Office Hours: M-TH 10:45-11:45PM

## Course Description

Animating non-humanoid characters comes with unique challenges and opportunities. Students explore new concepts of body mechanics and performance utilizing a wide range of creature types and behaviors. Students conceptualize and create complex, believable animalistic performances for their animated pieces. Prerequisite(s): ANIM 303.

## Student Learning Outcomes

1. Students will synthesize body mechanic research to generate believable movement.
2. Students will translate observed, natural body mechanics into advanced creature performance in animation.
3. Students will portray believable animalistic behaviors with clear motivation, thought and reactions.
4. Students will use the camera/creature relationship to support effective storytelling in their animated performances.

## Class Meeting Dates

1. Monday, September 14, 2026
2. Wednesday, September 16, 2026
3. Monday, September 21, 2026
4. Wednesday, September 23, 2026
5. Monday, September 28, 2026
6. Wednesday, September 30, 2026
7. Monday, October 5, 2026
8. Wednesday, October 7, 2026
9. Monday, October 12, 2026
10. Wednesday, October 14, 2026
11. Monday, October 19, 2026
12. Wednesday, October 21, 2026
13. Monday, October 26, 2026
14. Wednesday, October 28, 2026
15. Monday, November 2, 2026
16. Wednesday, November 4, 2026
17. Monday, November 9, 2026
18. Wednesday, November 11, 2026
19. Monday, November 16, 2026
20. Wednesday, November 18, 2026

## Pre-quarter Assignment

- Watch the "Class Introduction Video" (in Blackboard) to prepare your files and programs. Gather the required materials for this class.
- Read the Additional Course Information at the end of the syllabus.
- Watch Amazing Animal Moments from the BBC Earth documentary series. Scroll back and forth and analyze favorite moments of animal behavior.
- Watch Ostrich the Flightless Bird (documentary by ProArtnc and Beautiful Washington). Observe the ostrich's behavior and movements and capture key moments for the ostrich animation.

## Schedule of Classes

The Date column in the printed syllabus is empty. Classes appear in this order in the original, including 18 before 17.

### Class 1
- INTRO: Introductions, course overview, expectations, and guidelines.
- LAUNCH: Assignment 1: THE FLIGHTLESS BIRD. DUE Class 03.
- LECTURE: Exploring and studying an ostrich gait and behavior, analyzing ostrich references in movies and other sources and picking key frames for reference. How to analyze the reference.
- DEMO: Set up a workable project file. Review references. Rig overview. Demo of the Ostrich Walk.
- APPLY: Ostrich rig "Test & break" and start the Ostrich walk cycle animation.

### Class 2
- DAILIES: Submit your most recent progress to Syncsketch and put the link in Discord.
- LECTURE: Thinking like an Ostrich
- DEMO: Ostrich Walk cycle continued
- APPLY: Continue ostrich walk animation.

### Class 3
- DUE: Assignment 1: THE FLIGHTLESS BIRD. Submit the final movie file in Dropbox > "_Class_Share" > "A1_OstrichWalk"
- LAUNCH: Assignment 2: HORSE WALK. DUE Class 05.
- LECTURE: Horse Locomotion. Horse anatomy and how it relates to the animation. Focus on the walk cycle of a horse.
- DEMO: Demo Horse Rig. Part 01: Horse walk animation (hips/chest and legs)
- APPLY: Begin the horse walk cycle.

### Class 4
- DAILIES: Submit your most recent progress to Syncsketch and put the link in Discord.
- LECTURE: Fundamentals of the Horse Walk: closer look at the feet
- DEMO: Part 02: Horse walk animation (head/neck and tail)
- APPLY: Continue horse walk animations.

### Class 5
- DUE: Assignment 2: HORSE WALK. Submit the final movie file in Dropbox > "_Class_Share" > "A2_HorseWalk"
- LAUNCH: Assignment 2: HORSE TROT. DUE Class 07.
- LECTURE: Fundamentals of the Horse Trot.
- DEMO: Part 01: Horse Trot Animation (hips/chest and legs)
- APPLY: Begin horse trot animation.

### Class 6
- DAILIES: Submit your most recent progress to Syncsketch and put the link in Discord.
- DEMO: Part 02: Horse Trot Animation (head/neck and tail)
- APPLY: Continue horse trot animation.

### Class 7
- DUE: Assignment 2: HORSE TROT. Submit the final movie file in Dropbox > "_Class_Share" > "A2_HorseTrot"
- LAUNCH: Assignment 2: HORSE GALLOP. DUE Class 09.
- LECTURE: Fundamentals of the Horse Gallop.
- DEMO: Part 01: Horse Gallop Animation (hips/chest and legs)
- APPLY: Begin horse gallop animation.

### Class 8
- DAILIES: Submit your most recent progress to Syncsketch and put the link in Discord.
- LECTURE: Transitioning from one cycle to another
- DEMO: Part 02: Horse Gallop animation (head/neck and tail) + transitioning cycles
- APPLY: Continue horse gallop animation.

### Class 9
- DUE: Assignment 2: HORSE GALLOP. Submit the final movie file in Dropbox > "_Class_Share" > "A2_HorseGallop"
- LAUNCH: Assignment 3: BIRD IN FLIGHT. DUE Class 13.
- LECTURE: Birds and flight.
- DEMO: Demo Bird Rig. Part 01: Bird animation (flying and gliding)
- APPLY: Begin Bird Animation.

### Class 10
- DAILIES: Submit your most recent progress to Syncsketch and put the link in Discord.
- LECTURE: Bird flight: examine and analyze footage of animated birds in film and television, types of wings and flights, and the body mechanics involved.
- DEMO: Part 02: Bird Animation (flying/gliding continued)
- APPLY: Continue Bird Animation.

### Class 11
- DAILIES: Submit your most recent progress to Syncsketch and put the link in Discord.
- LECTURE: Landing mechanics
- DEMO: Part 03: Bird Animation (Landing)
- APPLY: Continue Bird Animation.

### Class 12
- DAILIES: Submit your most recent progress to Syncsketch and put the link in Discord.
- LECTURE/DEMO: Muddiest Point. Finding good rigs. Introduce A4. Start planning what creature/rig to use.
- APPLY: Continue bird in flight and find a suitable rig for A4.

### Class 13
- DUE: Assignment 3: BIRD IN FLIGHT. Submit the final movie file in Dropbox > "_Class_Share" > "A3_BirdInFlight"
- LAUNCH: Assignment 4: CREATURE LOCOMOTION. DUE Class 16.
- LECTURE: Creature locomotion. Fantasy or real, how to create locomotion for any creature.
- DEMO: Steps taken to animate a fantasy creature.
- APPLY: Begin creature locomotion animation after finding an approved rig.

### Class 14
- LECTURE: Naturalistic vs. Performance animation. Quadruped gaits and behaviors (digitigrade, ungulate, plantigrade); analyzing quadruped references.
- Guest appearance from SCADamp on preparing your slide deck.
- APPLY: Continue creature locomotion animation and the presentation for the research portion of the assignment.

### Class 15
- DAILIES: Submit your most recent progress to Syncsketch and put the link in Discord.
- LECTURE: Blocking out animation. Spline vs. stepped. Stay in blocking as long as you can. Addressing notes. Layer method vs. pose to pose.
- DEMO: In-betweens and creating moving holds. On-the-spot notes from the class.
- APPLY: Continue creature locomotion animation.

### Class 16
- DUE: Assignment 4: CREATURE LOCOMOTION. Submit final movie file and presentation in Dropbox > "_Class_Share" > "A4_CreatureLocomotion"
- LAUNCH: Assignment 5: CREATURE FEATURE. DUE Class 20.
- LECTURE: Creature behaviors.
- APPLY: Find reference videos for your creature to mimic and begin animating.

### Class 18
- LECTURE: The importance of body mechanics, weight, and timing in a fantasy creature animation.
- DEMO: Adding/improving weight in the fantasy creature animation.
- APPLY: Keep animating the creature's behavior.

### Class 17
- DAILIES: Submit your most recent progress as well as the reference footage to Syncsketch and put the link in Discord.
- LECTURE: How cameras are handled in fantasy creature animated movies. Analyze footage focusing on camera action.
- DEMO: Camera work.
- APPLY: Start wrapping up fantasy creature animations.

### Class 19
- DAILIES: Submit your most recent progress as well as the reference footage to Syncsketch and put the link in Discord.
- LECTURE: Rendering for your reel. Lighting, camera, and staging.
- DEMO: How to create proper renders that are quick and easy.
- APPLY: Wrap up fantasy creature animations.

### Class 20
- DUE: Assignment 5: CREATURE FEATURE. Submit Final for review in Dropbox > "_Class_Share" > "A5_CreatureFeature"
- LECTURE: Final considerations and reel critiques.

## Grading Opportunities

| # | Due Date | Assignment | Weight |
|---|---|---|---|
| 1 | 9/21/26 | The Flightless Bird | 10 |
| 2 | 10/12/26 | Horse Locomotion (Walk, Trot, Gallop) | 30 |
| 3 | 10/26/26 | Bird in Flight | 15 |
| 4 | 11/4/26 | Creature Locomotion | 20 |
| 5 | 11/18/26 | Creature Feature | 25 |

## Grading Standards

| Letter Grade | Quality | Range | Undergraduate Quality Points | Graduate Quality Points |
|---|---|---|---|---|
| A | Excellent | 90 - 100% | 4 | 4 |
| B | Good | 80 - 89% | 3 | 3 |
| C | Satisfactory | 70 - 79% | 2 | 2 |
| D | Poor | 60 - 69% | 1 | 0 |
| F | Failing | 0 - 59% | 0 | 0 |

## Required Readings

- Morpho: Mammals. Michel Lauricella. Rocky Nook, Inc., 2023-04-14. ISBN 9781681989990
- The Animator's Survival Kit. Richard Williams. Macmillan, 2012-09-25. ISBN 9780865478978

## Recommended Readings

- Animals in Motion. Eadweard Muybridge. Courier Corporation, 2012-09-24. ISBN 9780486129990
- Principles of Creature Design: Creating Imaginary Animals. Terryl Whitlatch. Design Studio Press, 2015. ISBN 9781624650215
- Science of Creature Design. Terryl Whitlatch. 2015-01-01. ISBN 9781624650291
- The Illusion of Life. Frank Thomas, Ollie Johnston. Disney Editions Deluxe, 1995-10-05

## Required Materials

- Sketchbook for notes and critiques in dailies, planning and sketching ideas for assignments.
- A good pen/pencil.
- A USB storage device/external hard drive for storage, backup and transfer of files. Use external drives only to back up and store files, not to work from during production.

## Study (Field) Trips

| Study Trip | Date | Description |
|---|---|---|
| 1 | 10/16/26 | Oatland Island Wildlife Center: gesture drawings of each animal with an understanding of the skeleton underneath (ribs, pelvis, skull). Bring paper and pencil, sunscreen, water, maybe lunch. Meet at the Center at 11am, stay until 3pm. Buses provided. More info in class. |
| 2 | 9/23/26 | SCAD ANIM FEST, Wednesday, Sept. 23 - Friday, Sept. 25 |

## Extra Help Sessions

| Session | Date | Description |
|---|---|---|
| 1 | 10/9/26 | 09:00 AM - 11:00 AM, Monty 311 |
| 2 | 10/23/26 | 09:00 AM - 11:00 AM, Monty 311 |
| 3 | 10/30/26 | 09:00 AM - 10:00 AM, Monty 311 |

## Extended Learning Opportunities

University-wide extended learning opportunities (SCADamp workshops, SCADextra workshops, events and exhibitions, guided studio work, virtual engagements), on-ground and virtual.

- https://myevents.scad.edu/
- https://app.scad.edu/workshops/

Course-specific opportunities may also be communicated via Blackboard.

## Additional Course Information

- **Late work:** Not accepted. Homework must be submitted to the correct Dropbox folder by the start of the class period, or it receives a zero. Submitting to the wrong folder counts as late. The Dropbox time-stamp is the official submission time, so don't overwrite your original final submission. Missing a deadline for sickness requires a doctor's note, and the work is due the day you return or on a day agreed with the professor.
- **Putting in the time:** Allocate at least 18 hours (3 hours a day) of computer animation time per week. Save often and keep backups.
- **Grades:** The syllabus explains that grading starts at F and work earns its way up. Missed deadlines and missed checkpoints prevent an A.

## Other Dated Items

- **Midterm Conference(s):** Scheduled outside class time with the professor. Students are expected to keep this appointment.
- **Course Evaluations:** Available during Weeks 8, 9, and 10 through MySCAD.
- **Attendance:** Absences in excess of 20% of the course result in a failing grade. On-ground: time away from class over 15 minutes in a session counts as an absence.

## Omitted from this text version

SCAD mission, vision and values; bookstore and library information; the full grade-level descriptions; full academic integrity, attendance, enrollment, accommodations and survey policies. See the source PDF for these.
