# ESF Companion State

This file holds mutable local state for the workflow. Onboarding and session memory update this file instead of editing plugin files.

## Identity

- **Name:** Vijay
- **Preferred name:** Vijay
- **Role or program:** Student, AI 101
- **Discipline or focus:** AI applications; calendar/planner agent
- **Current period:** Fall 2026

## Active Contexts

- `AI101`: AI 101 coursework, including the Syllabus to Calendar project using AI101 and ANIM223 syllabi
  Collaborator or lead: not specified
  ESF level: full
  Records of Resistance required: no course minimum; self-defined
  Position Statement timing: self-defined

## Current Project

- **Context:** AI101
- **Project name:** Syllabus to Calendar
- **Brief location:** `project-02/00-start-here.md`
- **Position Statement:** `esf/AI101/position-statements/calendar-planner-agent.md`
- **Phase:** Make
- **Project type:** Creative/Scholarly
- **Last session:** 2026-10-23
- **Scaffolding level:** not yet set

## Preferences

- **silent_mode:** false

## Growth Record

None yet.
