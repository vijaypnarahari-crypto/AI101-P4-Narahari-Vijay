# ESF Companion State

This file holds mutable local state for the Claude Code workflow.
Onboarding and session memory update this file instead of editing `.claude/`.

## Identity

- **Name:** not set
- **Preferred name:** not set
- **Role or program:** not set
- **Discipline or focus:** not set
- **Current period:** not set

## Active Contexts

Use this format for each context:

- `context-code`: brief description
  Collaborator or lead: optional
  ESF level: full | lightweight | drift-only
  Records of Resistance required: yes/no, count if known
  Position Statement timing: project start | other | self-defined

## Current Project

- **Context:** not set
- **Project name:** not set
- **Brief location:** `esf/[context]/briefs/[brief-file]`
- **Position Statement:** `esf/[context]/position-statements/[project-name].md`
- **Phase:** Inquire
- **Project type:** not set
- **Last session:** none yet
- **Scaffolding level:** not yet set

## Preferences

<!-- companion-notes.md lives in the same directory as this file. See templates/companion-notes-template.md. -->
- **silent_mode:** false

## Growth Record

None yet.
