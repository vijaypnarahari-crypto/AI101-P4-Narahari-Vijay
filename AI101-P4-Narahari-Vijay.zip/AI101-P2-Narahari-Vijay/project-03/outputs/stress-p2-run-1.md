---
run: Project 2 workflow (source-check skill + project-02 step files)
input: project-02/input/stress-test/AI101-syllabus.md
courses: AI101 only
run-date: 2026-10-23
status: calendar built for dated items. Undated items NOT scheduled. Waiting on you.
---

# P2 Run: AI101 Stress-Test Syllabus

## Calendar

Class meets Tue / Thu, 5:00 PM - 7:30 PM, SATLAB 123. Weeks run Monday to Sunday.

### Week of Sep 14 - Sep 20
| Date | Day | Course | Event | As written in syllabus |
|---|---|---|---|---|
| 9/15 | Tue | AI101 | Class 1: Set Up Your Practice (Unit 1: Foundations) | Class Meeting Dates #1 |
| 9/15 | Tue | AI101 | Assignment due: Pre-quarter Assignment, "Your Agent Brief" | "By the first class meeting" |
| 9/17 | Thu | AI101 | Class 2: Make Something | Class Meeting Dates #2 |

### Week of Sep 21 - Sep 27
| Date | Day | Course | Event | As written in syllabus |
|---|---|---|---|---|
| 9/22 | Tue | AI101 | Class 3: See the Whole Room | Class Meeting Dates #3 |
| 9/24 | Thu | AI101 | Class 4: Name the Trade | Class Meeting Dates #4 |
| 9/24 | Thu | AI101 | Project due: Project 1: Make, Then Compare (15%) | Grading Opportunities #1, 9/23/26 |

### Week of Sep 28 - Oct 4
| Date | Day | Course | Event | As written in syllabus |
|---|---|---|---|---|
| 9/29 | Tue | AI101 | Class 5: Name the Process (Unit 2: The Design Process) | Class Meeting Dates #5 |
| 10/1 | Thu | AI101 | Class 6: Verify Your Sources | Class Meeting Dates #6 |

### Week of Oct 5 - Oct 11
| Date | Day | Course | Event | As written in syllabus |
|---|---|---|---|---|
| 10/6 | Tue | AI101 | Class 7: Build a Pipeline | Class Meeting Dates #7 |
| 10/8 | Thu | AI101 | Class 8: Take Feedback, Iterate | Class Meeting Dates #8 |
| 10/8 | Thu | AI101 | Project due: Project 2: Small Orchestration (20%) | Grading Opportunities #2, 10/7/26 |

### Week of Oct 12 - Oct 18
| Date | Day | Course | Event | As written in syllabus |
|---|---|---|---|---|
| 10/13 | Tue | AI101 | Class 9: Disclosure and Position (Unit 3: Your Field) | Class Meeting Dates #9 |
| 10/15 | Thu | AI101 | Class 10: Study Your Field | Class Meeting Dates #10 |

### Week of Oct 19 - Oct 25
| Date | Day | Course | Event | As written in syllabus |
|---|---|---|---|---|
| 10/20 | Tue | AI101 | Class 11: Build for Your Field | Class Meeting Dates #11 |
| 10/22 | Thu | AI101 | Class 12: Crit and Revise | Class Meeting Dates #12 |
| 10/22 | Thu | AI101 | Project due: Project 3: Your Field, With AI (20%) | Grading Opportunities #3, 10/21/26 |

### Week of Oct 26 - Nov 1
| Date | Day | Course | Event | As written in syllabus |
|---|---|---|---|---|
| 10/27 | Tue | AI101 | Class 13: Define Your Agent (Unit 4: Orchestration) | Class Meeting Dates #13 |
| 10/29 | Thu | AI101 | Class 14: Assemble the Sources | Class Meeting Dates #14 |

### Week of Nov 2 - Nov 8
| Date | Day | Course | Event | As written in syllabus |
|---|---|---|---|---|
| 11/3 | Tue | AI101 | Class 15: Build and Test | Class Meeting Dates #15 |
| 11/5 | Thu | AI101 | Class 16: Find the Failures | Class Meeting Dates #16 |

### Week of Nov 9 - Nov 15
| Date | Day | Course | Event | As written in syllabus |
|---|---|---|---|---|
| 11/10 | Tue | AI101 | Class 17: Revise | Class Meeting Dates #17 |
| 11/12 | Thu | AI101 | Class 18: Confirm the Difference | Class Meeting Dates #18 |

### Week of Nov 16 - Nov 22
| Date | Day | Course | Event | As written in syllabus |
|---|---|---|---|---|
| 11/17 | Tue | AI101 | Class 19: Demo and Defend | Class Meeting Dates #19 |
| 11/19 | Thu | AI101 | Class 20: Reflect and Carry Forward | Class Meeting Dates #20 |
| 11/19 | Thu | AI101 | Project due: Capstone: Your Own Agent (30%) | Grading Opportunities #4, 11/18/26 |
| 11/19 | Thu | AI101 | Assignment due: Professional Practice (15) | Grading Opportunities #5, 11/18/26 |

**Count:** 26 events. That is 20 classes, 1 pre-quarter assignment, and 5 grading items.

## Not yet scheduled (I need your answer)

I did not pick a date for any of these. Rule 3 says stop and ask.

| # | Item | What the syllabus says | Why I can't date it |
|---|---|---|---|
| 1 | Office Hours | "TBD, Zoom: https://scad.zoom.us/j/8382024752" | No day or time. |
| 2 | Study (Field) Trip 1 | "TBD and will announce on BB" | No date. |
| 3 | Extra Help Sessions 1, 2, 3, 4 | "Extra Help Session are on Fridays, Date and Time will be announced on BB" | Fridays only. No dates or times. The rows are also listed in the order 1, 2, 4, 3. |
| 4 | Midterm Conference | "scheduled outside of class time with the professor" | No date. |
| 5 | Course Evaluations | "Weeks 8, 9, and 10 through MySCAD" | The syllabus never says which dates are Week 8, 9, 10. No start or end day. |
| 6 | GitHub account setup | "set up in class, Week 2" | Week 2 has two classes (3 and 4). It doesn't say which one. |

My questions for you:
1. Office hours, trip, extra help, midterm conference: should these stay unscheduled until you have dates? Or will you give me dates?
2. Course Evaluations: if Week 1 is the week of Sep 14, then Weeks 8 to 10 are Nov 2 to Nov 22. That is my guess, not the syllabus. Is Week 1 = week of Sep 14? And do you want one event for the whole window?
3. GitHub setup: Class 3 (9/22) or Class 4 (9/24)? Or leave it off?

## Overlaps

Only one course is in this run. So I can't check AI101 against a second course. The cross-course check (step 4) did not really run.

Inside AI101, I found one overlap:

| Dates | Items | Why flagged |
|---|---|---|
| Thu 11/19 | AI101 Capstone: Your Own Agent (30%) and AI101 Professional Practice (15) | Same day |

No week has three or more due items. I did not rank them. That is your call.

## Which date decision I used (hard rule 3)

I used your decision in `project-02/decision-note.md`. It applies to AI101 only, and only when the two date lists don't match.

- **They don't match.** Every class in the Schedule of Classes is one day earlier than the same class in Class Meeting Dates. Example: Class 1 is 9/14 in one list and 9/15 in the other.
- **Decision used:** Class Meeting Dates. I ignored the dates in the Schedule of Classes.
- **Grading items:** each grading date equals the Schedule of Classes date for one class. I moved it to that class's meeting date, like you did in the first run:

| Item | Grading table date | Matches schedule | Calendar date |
|---|---|---|---|
| Project 1 | 9/23/26 | Class 4 | Thu 9/24 |
| Project 2 | 10/7/26 | Class 8 | Thu 10/8 |
| Project 3 | 10/21/26 | Class 12 | Thu 10/22 |
| Capstone | 11/18/26 | Class 20 | Thu 11/19 |
| Professional Practice | 11/18/26 | Class 20 | Thu 11/19 |

Each one matched exactly, so I did not need to ask.

## How I got the dates (hard rule 1)

- "Class 5" means number 5 in Class Meeting Dates. That is Tuesday, September 29.
- "By the first class meeting" means Class 1. That is Tuesday, September 15.
- Grading dates: see the table above.

## Things you didn't ask for (flagging)

- I listed the Pre-quarter Assignment. Your skill says "assignments," so I kept it. Tell me if you want it out.
- I wrote the unit names in the class rows (Unit 1 to Unit 4). They are in the schedule text.
- I did not add "start your AI Use Log" (Class 1) or "publish your folder to GitHub" (Class 4) as separate events. They are in-class tasks, not dates.
- I did not add the ELO links. They have no dates.
- Professional Practice shows weight "15" with no % sign in the syllabus. I copied it as written. Typo? Your call.
- Your decision note says you'd add two hours of study time before each due date. That is not in `hard-rules.md` or the skill. So I did not add it. Want it?
- Last time you asked for a Google-calendar look. That is not in this workflow. I did not make it.
- Nothing is marked late. Some dates are before today (10/23). You said you don't want that flagged.

## Human check (needed from you)

Nothing is final until you check it. Pick three rows in the calendar. Look up the class number in Class Meeting Dates. Tell me if they match.

## Run log (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Run Project 2 workflow on `project-02/input/stress-test/AI101-syllabus.md` only. Save to `project-03/outputs/p2-run.md`. Don't touch `project-02/`. | Created this file. Nothing in `project-02/` was changed. | Waiting on you |
| (my call) Used the decision note for class meeting dates and grading dates | 20 classes and 5 grading items use class meeting dates. The Pre-quarter Assignment sits on Class 1. | Waiting on you |
| (my call) Left 6 undated items off the calendar | Listed under "Not yet scheduled" | Waiting on you |
| (my call) Same-day overlap flagged, not ranked | Capstone and Professional Practice on 11/19 | Waiting on you |
