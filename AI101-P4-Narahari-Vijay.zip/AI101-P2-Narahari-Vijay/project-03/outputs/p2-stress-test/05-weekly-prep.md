---
run: Project 2 workflow, Step 5 (project-02/05-review-weekly.md), model prep only
input: project-03/outputs/p2-stress-test/calendar.md, overlaps.md
run-date: 2026-10-23 (Friday)
window: Fri 10/23 to Thu 11/5 (14 days, starting today)
status: Prepared. Stopped. The review is yours.
---

# Next 14 days: AI101 stress test

| Date | Day | Course | Event |
|---|---|---|---|
| 10/27 | Tue | AI101 | Class 13: Define Your Agent |
| 10/29 | Thu | AI101 | Class 14: Assemble the Sources |
| 11/3 | Tue | AI101 | Class 15: Build and Test |
| 11/5 | Thu | AI101 | Class 16: Find the Failures |

**4 events.** No assignments, projects, or tests are due in this window.

## Overlaps in this window

None. `overlaps.md` has 0 overlaps.

## Not in the window list, but could land in it

These have no date, so I can't place them. Extra help sessions fall on Fridays, so one could be 10/23, 10/30, or 11/6 (the window ends 11/5). Check Blackboard for:
- Extra Help Sessions 1 to 4
- Study Trip 1
- Midterm Conference
- Office Hours
- Course Evaluations ("Weeks 8, 9, and 10")

## Your part (I did not do these)

1. Check each date above against the syllabus and the past week's announcements.
2. Write corrections in `weekly-review.md` under today's date: `Course | Item | Old date | New date | Source`. Or write "No changes".
3. Write your plan for any overlap. None this window.
4. Corrections go back to Step 3.

Nothing here counts as confirmed until you check it.

## Things to know

- Step 5 says it starts on Sunday evening. Today is Friday. You asked for it now, so I ran it now.
- The step wants `weekly-review.md` in `outputs/`, with an entry for every week so far. I did not create one. It's your file, and `project-02/` is off limits in this run.
- Only AI101 is here. Step 5 also reads ANIM223.

## Run log (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Follow `05-review-weekly.md` | Created this prep file. Nothing in `project-02/` changed. No `weekly-review.md` written. | Waiting on you |
| (my call) Window = today through 11/5 | 14 days counted from today | Waiting on you |
