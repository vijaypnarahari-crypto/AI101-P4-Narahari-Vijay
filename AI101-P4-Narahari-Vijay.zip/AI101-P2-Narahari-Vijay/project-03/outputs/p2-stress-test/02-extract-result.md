---
run: Project 2 workflow, Step 2 only (project-02/02-extract-dated-items.md)
input: project-02/input/stress-test/AI101-syllabus.md
run-date: 2026-10-23
status: Step 2 done. Waiting on your human check and your answers. Not starting step 3.
---

# Step 2 report

Table: `dated-items.md` (same folder).

**Counts**
- AI101: 26 dated items (20 classes, 1 pre-quarter assignment, 5 grading items)
- ANIM223: 0 (not in this run)
- NEEDS DATE: 9

## Which date decision I used (hard rule 3)

The two AI101 date lists don't match. Every class is one day apart. So I used your `decision-note.md`: **Class Meeting Dates, not the Schedule of Classes.** AI101 only.

Grading dates: each one equals a Schedule of Classes date for exactly one class, so I moved it to that class's meeting date, like your first run. If you'd rather I ask each time, say so.

| Item | Syllabus date | Matches | Calendar date |
|---|---|---|---|
| Project 1 | 9/23/26 | Class 4 | Thu 9/24 |
| Project 2 | 10/7/26 | Class 8 | Thu 10/8 |
| Project 3 | 10/21/26 | Class 12 | Thu 10/22 |
| Capstone | 11/18/26 | Class 20 | Thu 11/19 |
| Professional Practice | 11/18/26 | Class 20 | Thu 11/19 |

## How I got the dates (hard rule 1)

- "Class N" = number N in Class Meeting Dates. Class 5 is Tuesday, September 29.
- "By the first class meeting" = Class 1. That is Tuesday, September 15.

## NEEDS DATE: I need you (hard rule 3)

I did not pick any of these.

1. Office Hours: "TBD". No day or time.
2. Study Trip 1: "TBD and will announce on BB".
3. Extra Help Sessions 1 to 4: "Fridays, date and time announced on BB". No dates.
4. Midterm Conference: "outside of class time". No date.
5. Course Evaluations: "Weeks 8, 9, and 10". The syllabus gives no dates for weeks, so I can't match them.
6. GitHub setup: "in class, Week 2". Same problem. It could be Class 3 or Class 4.

Do you have dates for any of these? Or should they stay unscheduled?

## Things you didn't ask for (flagging)

- **The 9 NEEDS DATE rows are not classes, readings, assignments, projects, or tests.** Step 2 only lists those. I gave them type `other`, which is not in the step's type list. Your decision note says you kept trips and extra help before. Keep or drop?
- **Types for grading items are my reading.** The syllabus doesn't say. I called Projects 1-3 and Capstone `project`, and Professional Practice `assignment`.
- **Pre-quarter Assignment** is included as an assignment. It has no date written, only "first class meeting".
- **Not extracted:** in-class tasks like "start your AI Use Log" (Class 1) and "publish your folder to GitHub" (Class 4). They have no date apart from their class. No readings, quizzes, or tests appear in this syllabus. The ELO links have no dates. No "no class" days are listed.
- **Syllabus oddities, copied as written:** Extra Help rows go 1, 2, 4, 3. Professional Practice weight is "15" with no % sign.
- **Not checked:** whether this is the latest syllabus (still your check from Step 1). Still one course, markdown input.

## Human check (yours)

Pick three AI101 items. Look up the class number in Class Meeting Dates. Tell me if the dates match. If any is wrong, tell me which, and I rerun Step 2.

## Run log (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Follow `02-extract-dated-items.md` on the stress-test AI101 syllabus. Save to `project-03/outputs/p2-stress-test/`. | Created `dated-items.md` and this report. Nothing in `project-02/` changed. | Waiting on you |
| (my call) Went ahead without the "Start step 2" phrase, since you asked for Step 2 directly. Flags 1 and 2 from Step 1 are still open. | Ran with one course, markdown input. | Waiting on you |
| (my call) Used decision-note: Class Meeting Dates, and moved 5 grading dates | See table above | Waiting on you |
| (my call) Added 9 NEEDS DATE rows typed `other` | See flags | Waiting on you |
