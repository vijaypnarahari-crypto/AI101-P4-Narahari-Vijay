---
run: Project 2 workflow, Step 1 only (project-02/01-collect-syllabi.md)
input: project-02/input/stress-test/AI101-syllabus.md
run-date: 2026-10-23
status: Step 1 done by the model's side. NOT moving to Step 2. Waiting on you.
---

# Step 1: Collect the syllabi (stress test)

No calendar yet. Step 1 only collects and checks. The calendar comes in later steps.

## Result

**Step 1 is not fully met. I stopped here.** The step file says the run does not move to Step 2 until you say so. Two things are off, and one is a call for you.

## What I checked

| Check from the step file | Result |
|---|---|
| Input file exists | Yes. `project-02/input/stress-test/AI101-syllabus.md` |
| Only the one input was used | Yes. I did not open `input/Syllabi/` content (AI101.pdf, ANIM223.pdf, ANIM353). |
| Has a schedule of class meeting dates | Yes. "Class Meeting Dates" lists 20 classes, Tue/Thu. Sep 15 to Nov 19, 2026. |
| Weekdays in that list match the calendar | Yes. All 20 are real Tuesdays and Thursdays. |
| Also has a Schedule of Classes | Yes. 20 class rows plus unit headings. |
| Exactly two files, AI101 and ANIM223 | **No.** This run has one file. |
| File is a PDF | **No.** It is a Markdown text copy. |
| Latest version posted | **I can't tell.** The file says "printed 10/4/26". I can't check Blackboard. That is your check. |

## Flags (you decide)

1. **Only one course.** Step 1 says two syllabi. This run has AI101 only. So the cross-course overlap check later can't really run. You told me to use this one file only, so I did. Is one course OK for this test?
2. **Markdown, not PDF.** Step 1 says PDF. This one is a text copy. Fine for a stress test? Your call.
3. **Date lists don't match (AI101).** Class Meeting Dates and Schedule of Classes disagree on every class. Example: Class 1 is Tue 9/15 in one list and Mon 9/14 in the other. The Schedule dates fall on Mondays and Wednesdays. The class meets Tue/Thu.
   - Your `decision-note.md` covers this case for AI101: use Class Meeting Dates.
   - I **did not apply it** in this step. Dates get used in Step 2. I'm noting it so it isn't a surprise.
   - Heads up: the Grading Opportunities dates (9/23, 10/7, 10/21, 11/18) match the Schedule of Classes dates, not the meeting dates. Hard rule 3 applies there too.
4. **Undated items I saw.** Study trip ("TBD"), office hours ("TBD"), four extra help sessions ("Fridays, date announced on BB"), midterm conference, course evaluations ("Weeks 8, 9, and 10"). None has a clear date. When we get to dates, I will ask. I won't pick.
5. **Odd spots in the text** (not fixing, just telling you):
   - Extra Help rows are numbered 1, 2, 4, 3.
   - Professional Practice weight is "15" with no % sign.
   - Pre-quarter Assignment is due "by the first class meeting." No date written.

## Not in your request (flagging)

- A file `project-03/outputs/p2-run.md` already exists from an earlier run today. I did read it while orienting, before I wrote this. I did not change it or copy from it. Everything here comes from the syllabus and your rule files.
- `project-02/ai-use-log.md` shows as modified in git. I did not touch it. I touched nothing in `project-02/`.

## Next

Say "Inputs are ready. Start step 2." when you are OK with flags 1 and 2. I will not start without it.

## Run log (hard rule 5)

| What you asked | What changed | Keep / change / reject |
|---|---|---|
| Run Step 1 (`01-collect-syllabi.md`) on `project-02/input/stress-test/AI101-syllabus.md` only. Save to `project-03/outputs/p2-stress-test/`. Don't change `project-02/`. | Created this file and the session buffer. Nothing in `project-02/` changed. | Waiting on you |
| (my call) Stopped before Step 2 | Step 2 needs your go-ahead. Input also fails "two PDFs." | Waiting on you |
| (my call) Did not apply the decision note yet | Noted the date mismatch only | Waiting on you |
