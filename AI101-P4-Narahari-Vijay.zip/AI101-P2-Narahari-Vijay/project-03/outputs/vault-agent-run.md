# Syllabus Calendar Run — 2026-10-24

Sources: `project-02/input/Syllabi/AI101.pdf`, `ANIM223.pdf`, and `ANIM353.pdf` only.

Three syllabi were found, one for each course, and each lists its class meeting dates. All three converted-item checks were confirmed. The AI101 Schedule of Classes is one day earlier than its Class Meeting Dates list throughout the schedule; the calendar uses the Class Meeting Dates list. For four AI101 graded dates, you explicitly chose the Class Meeting Dates entry.

## Calendar by week

Study blocks are two hours and appear on the day before each due item. When multiple blocks land on one day, each is listed separately.

### Sep 14–20

- **Mon Sep 14:** ANIM353 Class 1; 2-hour study block — AI101 Your Agent Brief.
- **Tue Sep 15:** AI101 Class 1; ANIM223 Class 1; AI101 Your Agent Brief due (by first class meeting).
- **Wed Sep 16:** ANIM353 Class 2.
- **Thu Sep 17:** AI101 Class 2; ANIM223 Class 2.
- **Sun Sep 20:** 2-hour study block — ANIM353 Assignment 1: THE FLIGHTLESS BIRD.

### Sep 21–27

- **Mon Sep 21:** ANIM353 Class 3; ANIM353 Assignment 1: THE FLIGHTLESS BIRD due.
- **Tue Sep 22:** AI101 Class 3; ANIM223 Class 3 (Reading: *A New History of Animation*, Chapters 3 & 4).
- **Wed Sep 23:** ANIM353 Class 4; 2-hour study block — AI101 Project 1: Make, Then Compare.
- **Thu Sep 24:** AI101 Class 4; ANIM223 Class 4 (Reading: *A New History of Animation*, Chapters 5 & 6); AI101 Project 1: Make, Then Compare due.
- **Sun Sep 27:** 2-hour study block — ANIM353 Assignment 2: HORSE WALK.

### Sep 28–Oct 4

- **Mon Sep 28:** ANIM353 Class 5; ANIM353 Assignment 2: HORSE WALK due.
- **Tue Sep 29:** AI101 Class 5; ANIM223 Class 5.
- **Wed Sep 30:** ANIM353 Class 6.
- **Thu Oct 1:** AI101 Class 6; ANIM223 Class 6 (Reading: *A New History of Animation*, Chapters 7 & 8).
- **Sun Oct 4:** 2-hour study block — ANIM353 Assignment 2: HORSE TROT.

### Oct 5–11

- **Mon Oct 5:** ANIM353 Class 7; ANIM353 Assignment 2: HORSE TROT due.
- **Tue Oct 6:** AI101 Class 7; ANIM223 Class 7.
- **Wed Oct 7:** ANIM353 Class 8; 2-hour study block — AI101 Project 2: Small Orchestration.
- **Thu Oct 8:** AI101 Class 8; ANIM223 Class 8 (Reading: *A New History of Animation*, Chapter 9); AI101 Project 2: Small Orchestration due.
- **Sun Oct 11:** 2-hour study block — ANIM353 Assignment 2: HORSE GALLOP.

### Oct 12–18

- **Mon Oct 12:** ANIM353 Class 9; ANIM353 Assignment 2: HORSE GALLOP due. The Grading Opportunities table lists Horse Locomotion (Walk, Trot, Gallop) on this date, matching Class 9.
- **Tue Oct 13:** AI101 Class 9; ANIM223 Class 9 (Reading: *A New History of Animation*, Chapters 10 & 11).
- **Wed Oct 14:** ANIM353 Class 10; 2-hour study block — ANIM223 Assignment 1 - Written summaries of textbook chapters 1 thru 11; 2-hour study block — ANIM223 Midterm Test.
- **Thu Oct 15:** AI101 Class 10; ANIM223 Class 10; ANIM223 Assignment 1 - Written summaries of textbook chapters 1 thru 11 due; ANIM223 Midterm Test due (in class); ANIM223 extra help session, 2–4 pm, Room 309.
- **Sun Oct 18:** No additional dated items found.

### Oct 19–25

- **Mon Oct 19:** ANIM353 Class 11.
- **Tue Oct 20:** AI101 Class 11; ANIM223 Class 11 (Reading: *A New History of Animation*, Chapters 12 & 13).
- **Wed Oct 21:** ANIM353 Class 12; 2-hour study block — AI101 Project 3: Your Field, With AI.
- **Thu Oct 22:** AI101 Class 12; ANIM223 Class 12; AI101 Project 3: Your Field, With AI due.
- **Sat Oct 24:** Calendar run date.
- **Sun Oct 25:** 2-hour study block — ANIM353 Assignment 3: BIRD IN FLIGHT.

### Oct 26–Nov 1

- **Mon Oct 26:** ANIM353 Class 13; ANIM353 Assignment 3: BIRD IN FLIGHT due.
- **Tue Oct 27:** AI101 Class 13; ANIM223 Class 13 (Reading: *A New History of Animation*, Chapters 14 & 15).
- **Wed Oct 28:** ANIM353 Class 14.
- **Thu Oct 29:** AI101 Class 14; ANIM223 Class 14.

### Nov 2–8

- **Mon Nov 2:** ANIM353 Class 15.
- **Tue Nov 3:** AI101 Class 15; ANIM223 Class 15 (Reading: *A New History of Animation*, Chapters 16, 17 & 18); 2-hour study block — ANIM353 Assignment 4: CREATURE LOCOMOTION.
- **Wed Nov 4:** ANIM353 Class 16; ANIM353 Assignment 4: CREATURE LOCOMOTION due.
- **Thu Nov 5:** AI101 Class 16; ANIM223 Class 16 (Reading: *A New History of Animation*, Chapters 19 & 20).
- **Sat Nov 7:** ANIM223 Jen Library visit to view a selection of works from the Don Bluth Animation Production Collection, 10 am–12 pm.

### Nov 9–15

- **Mon Nov 9:** ANIM353 Class 17.
- **Tue Nov 10:** AI101 Class 17; ANIM223 Class 17.
- **Wed Nov 11:** ANIM353 Class 18.
- **Thu Nov 12:** AI101 Class 18; ANIM223 Class 18 (Reading: *A New History of Animation*, Chapters 21 & 22).

### Nov 16–22

- **Mon Nov 16:** ANIM353 Class 19; 2-hour study block — ANIM223 Assignment 3 - Written summaries of textbook chapters 12 thru 24; 2-hour study block — ANIM223 Assignment 4 - Team Presentation Project.
- **Tue Nov 17:** AI101 Class 19; ANIM223 Class 19; ANIM223 Assignment 3 - Written summaries of textbook chapters 12 thru 24 due; ANIM223 Assignment 4 - Team Presentation Project due (final slides by end of class); 2-hour study block — ANIM353 Assignment 5: CREATURE FEATURE.
- **Wed Nov 18:** ANIM353 Class 20; ANIM353 Assignment 5: CREATURE FEATURE due; 2-hour study block — AI101 Capstone: Your Own Agent; 2-hour study block — AI101 Professional Practice; 2-hour study block — ANIM223 Final Test.
- **Thu Nov 19:** AI101 Class 20; ANIM223 Class 20; AI101 Capstone: Your Own Agent due; AI101 Professional Practice due; ANIM223 Final Test due (in class).

## Overlap flags

- **Same-day due items from different courses:** November 19 — AI101 Capstone: Your Own Agent and Professional Practice, and ANIM223 Final Test.
- **Weeks with 3 or more due items:** Oct 12–18 has 3 (ANIM353 Horse Gallop; ANIM223 Assignment 1 summaries; ANIM223 Midterm Test). Nov 16–22 has 6 (ANIM223 Assignments 3 and 4; ANIM353 Creature Feature; AI101 Capstone and Professional Practice; ANIM223 Final Test).
- **Tests in different courses during the same week:** None found.
- Overlaps are flagged only; no assignment priority is assigned.

## Not yet scheduled (NEEDS DATE)

- **ANIM223:** Acquire the textbook and prepare for Class One (no deadline stated); volunteer to set up the Discord channel (no date stated); introduce yourself on Discord after receiving the invitation (invitation date not stated); review and familiarize yourself with the Blackboard course area (no date stated).
- **ANIM353:** Watch the Class Introduction Video and gather required materials (no deadline stated).
- **AI101:** No additional items without a clear date found.

## Next 14 days: Oct 24–Nov 7

- **Sun Oct 25:** 2-hour study block — ANIM353 Assignment 3: BIRD IN FLIGHT.
- **Mon Oct 26:** ANIM353 Class 13; ANIM353 Assignment 3: BIRD IN FLIGHT due.
- **Tue Oct 27:** AI101 Class 13; ANIM223 Class 13 and scheduled reading, Chapters 14 & 15.
- **Wed Oct 28:** ANIM353 Class 14.
- **Thu Oct 29:** AI101 Class 14; ANIM223 Class 14.
- **Mon Nov 2:** ANIM353 Class 15.
- **Tue Nov 3:** AI101 Class 15; ANIM223 Class 15 and scheduled reading, Chapters 16, 17 & 18; 2-hour study block — ANIM353 Assignment 4: CREATURE LOCOMOTION.
- **Wed Nov 4:** ANIM353 Class 16; ANIM353 Assignment 4: CREATURE LOCOMOTION due.
- **Thu Nov 5:** AI101 Class 16; ANIM223 Class 16 and scheduled reading, Chapters 19 & 20.
- **Sat Nov 7:** ANIM223 Jen Library visit, 10 am–12 pm.

## Decision log

- **Asked:** Build the calendar from the syllabi in `project-02/input/Syllabi/`. **Changed:** Included AI101, ANIM223, and the newly present ANIM353 syllabus. **Status:** keep.
- **Asked:** Which date to use for AI101 Project 1 (Grading Opportunities: Sep 23; Class Meeting Dates, Class 4: Sep 24). **Changed:** Used Sep 24 at your direction. **Status:** change.
- **Asked:** Which date to use for AI101 Project 2 (Grading Opportunities: Oct 7; Class Meeting Dates, Class 8: Oct 8). **Changed:** Used Oct 8 at your direction. **Status:** change.
- **Asked:** Which date to use for AI101 Project 3 (Grading Opportunities: Oct 21; Class Meeting Dates, Class 12: Oct 22). **Changed:** Used Oct 22 at your direction. **Status:** change.
- **Asked:** Which date to use for AI101 Capstone and Professional Practice (Grading Opportunities: Nov 18; Class Meeting Dates, Class 20: Nov 19). **Changed:** Used Nov 19 for both at your direction. **Status:** change.
- **Asked:** Check three converted items per course. **Changed:** You confirmed the three presented conversions for each course. **Status:** keep.
