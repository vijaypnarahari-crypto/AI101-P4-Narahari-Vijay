# P2 Run (original Project 2 outputs, AI101 + ANIM223)

Source: project-02/outputs/ as committed in c6ee626.

## Step 2: dated-items.md
# Dated items (Step 2)

Source: `input/Syllabi/AI101.pdf` (page footer dated 10/4/26) and `input/Syllabi/ANIM223.pdf` (page footer dated 9/8/26). No other source was used.

**Counts:** AI101 32 items (6 `NEEDS DATE`). ANIM223 45 items (3 `NEEDS DATE`). Total 77. No `no class` days are marked in either syllabus.

## Read this first: AI101 date source (your decision)

AI101's syllabus lists two sets of class dates. Per your decision, AI101 class dates come from the **Class Meeting Dates list** (Class 1 = Tuesday 9/15/26, Class 20 = Thursday 11/19/26), which fits the Tuesday / Thursday meeting time. The Schedule of Classes table dates (one day earlier) are ignored. No AI101 row is marked `DATE CONFLICT` now.

**Grading Opportunities dates (your decision):** Project 1 (9/23), Project 2 (10/7), Project 3 (10/21), Capstone and Professional Practice (11/18) were Wednesdays, one day before the matching class. They are moved to the Class Meeting Dates list dates for Class 4, 8, 12 and 20 (Thu 9/24, 10/8, 10/22, 11/19). The original written date stays in each row's "As written" and Notes.

The ANIM223 syllabus has no such problem: its schedule table Date column is blank, and its Class Meeting Dates list is the only class date source.

## Table

| Course  | Item (exact syllabus wording)                                                                                  | Type       | As written                                                                  | Calendar date                                                                                          | Notes                                                                                                                                                                                                                                         |
| ------- | -------------------------------------------------------------------------------------------------------------- | ---------- | --------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| AI101 | Class 1: Set Up Your Practice | class | Class 1 | Tue 2026-09-15 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| AI101 | Your Agent Brief | assignment | By the first class meeting. | Tue 2026-09-15 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. Pre-quarter Assignment, due by the first class meeting (Class 1). |
| ANIM223 | Lecture: The Beginning                                                                                         | class      | Class 1                                                                     | Tue 2026-09-15                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list. Also lists Classroom Activity: Student Introductions.                                                                                                     |
| ANIM223 | Reading: A New History of Animation - Chapters 1 &2                                                            | reading    | Class 1                                                                     | Tue 2026-09-15                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| ANIM223 | Launch Assignment 1: Unit 1 Paper                                                                              | assignment | Class 1                                                                     | Tue 2026-09-15                                                                                         | Launch only. Due dates are on the DUE rows below. Named "Unit 1 Paper" here and "Written summaries of textbook chapters 1 thru 11" under Grading Opportunities.                                                                               |
| AI101 | Class 2: Make Something | class | Class 2 | Thu 2026-09-17 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Innovation & Experimentation in the early Silent Era                                                  | class      | Class 2                                                                     | Thu 2026-09-17                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| AI101 | Class 3: See the Whole Room | class | Class 3 | Tue 2026-09-22 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Growth of the Animation Industry in the 1920's                                                        | class      | Class 3                                                                     | Tue 2026-09-22                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Reading: A New History of Animation - Chapters 3 & 4                                                           | reading    | Class 3                                                                     | Tue 2026-09-22                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| AI101 | Project 1: Make, Then Compare | project | 9/23/26 | Thu 2026-09-24 | Grading Opportunities date as written: 9/23/26, weight 15%. Moved to Thu 2026-09-24, the date of Class 4 in the Class Meeting Dates list (your decision). |
| AI101 | Class 4: Name the Trade | class | Class 4 | Thu 2026-09-24 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Animation Matures as an Art Form                                                                      | class      | Class 4                                                                     | Thu 2026-09-24                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Reading: A New History of Animation - Chapter 5 & 6                                                            | reading    | Class 4                                                                     | Thu 2026-09-24                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| AI101 | Class 5: Name the Process | class | Class 5 | Tue 2026-09-29 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: First Features and Better Storytelling with Improved Believability                                    | class      | Class 5                                                                     | Tue 2026-09-29                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| AI101 | Class 6: Verify Your Sources | class | Class 6 | Thu 2026-10-01 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Warner Bros.                                                                                          | class      | Class 6                                                                     | Thu 2026-10-01                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Reading: A New History of Animation, Chapters 7 & 8                                                            | reading    | Class 6                                                                     | Thu 2026-10-01                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| AI101 | Class 7: Build a Pipeline | class | Class 7 | Tue 2026-10-06 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: MGM and other Hollywood studios                                                                       | class      | Class 7                                                                     | Tue 2026-10-06                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| AI101 | Project 2: Small Orchestration | project | 10/7/26 | Thu 2026-10-08 | Grading Opportunities date as written: 10/7/26, weight 20%. Moved to Thu 2026-10-08, the date of Class 8 in the Class Meeting Dates list (your decision). |
| AI101 | Class 8: Take Feedback, Iterate | class | Class 8 | Thu 2026-10-08 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Wartime Animation                                                                                     | class      | Class 8                                                                     | Thu 2026-10-08                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Reading: A New History of Animation, Chapter 9                                                                 | reading    | Class 8                                                                     | Thu 2026-10-08                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| AI101 | Class 9: Disclosure and Position | class | Class 9 | Tue 2026-10-13 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Post-War and Midcentury Developments                                                                  | class      | Class 9                                                                     | Tue 2026-10-13                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Reading: A New History of Animation, Chapters 10 & 11                                                          | reading    | Class 9                                                                     | Tue 2026-10-13                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| AI101 | Class 10: Study Your Field | class | Class 10 | Thu 2026-10-15 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Rise of Stop Motion                                                                                   | class      | Class 10                                                                    | Thu 2026-10-15                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list. Class also lists DUE: Assignment 1 and DUE: Assignment 2 - Midterm Test.                                                                                  |
| ANIM223 | DUE: Assignment 1 - Submit remaining textbook summaries of chapters 1 thru 11.                                 | assignment | Class 10                                                                    | Thu 2026-10-15                                                                                         | Grading Opportunities row 1 gives 10/15/26 (matches).                                                                                                                                                                                         |
| ANIM223 | DUE: Assignment 2 - Midterm Test - Multiple choice and short answer - In Class Only                            | test       | Class 10                                                                    | Thu 2026-10-15                                                                                         | Grading Opportunities row 2 gives 10/15/26 (matches). "taken in class only today Class 10".                                                                                                                                                   |
| ANIM223 | Launch Assignment 3: Unit 3 Paper                                                                              | assignment | Class 10                                                                    | Thu 2026-10-15                                                                                         | Launch row says "Due by the beginning of Class 19".                                                                                                                                                                                           |
| ANIM223 | Extra Help Session 1                                                                                           | class      | 10/15/26: "Thursday week 5, from 2 pm tho 4 pm in room 309"                 | Thu 2026-10-15                                                                                         | Date given directly. Same day as Class 10 (Midterm Test, Assignment 1 due). Type is nearest fit. Syllabus does not list week dates, so "week 5" was not converted.                                                                            |
| AI101 | Class 11: Build for Your Field | class | Class 11 | Tue 2026-10-20 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Animation Moves to the Small Screen as Live Action Did                                                | class      | Class 11                                                                    | Tue 2026-10-20                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Reading: A New History of Animation, Chapters 12 & 13                                                          | reading    | Class 11                                                                    | Tue 2026-10-20                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| AI101 | Project 3: Your Field, With AI | project | 10/21/26 | Thu 2026-10-22 | Grading Opportunities date as written: 10/21/26, weight 20%. Moved to Thu 2026-10-22, the date of Class 12 in the Class Meeting Dates list (your decision). |
| AI101 | Class 12: Crit and Revise | class | Class 12 | Thu 2026-10-22 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Experimentation and Computers                                                                         | class      | Class 12                                                                    | Thu 2026-10-22                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| AI101 | Class 13: Define Your Agent | class | Class 13 | Tue 2026-10-27 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: The Beginning of a Decline in Animated Theatrical Features                                            | class      | Class 13                                                                    | Tue 2026-10-27                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Reading: A New History of Animation, Chapters 14 & 15                                                          | reading    | Class 13                                                                    | Tue 2026-10-27                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| AI101 | Class 14: Assemble the Sources | class | Class 14 | Thu 2026-10-29 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Bluth, Bakshi, & Williams                                                                             | class      | Class 14                                                                    | Thu 2026-10-29                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Launch Assignment 4 Team Presentation Project - All are Due by start of Class 19                               | project    | Class 14; due: start of Class 19                                            | Thu 2026-10-29                                                                                         | Class 19 row says final submission is "by the end of Class 19". Start vs end of Class 19 disagree within the syllabus. Not resolved. Weight 25%.                                                                                              |
| AI101 | Class 15: Build and Test | class | Class 15 | Tue 2026-11-03 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Animation Festivals & Short Films                                                                     | class      | Class 15                                                                    | Tue 2026-11-03                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Reading: A New History of Animation, Chapters 16, 17, & 18                                                     | reading    | Class 15                                                                    | Tue 2026-11-03                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| AI101 | Class 16: Find the Failures | class | Class 16 | Thu 2026-11-05 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Animation in Canada                                                                                   | class      | Class 16                                                                    | Thu 2026-11-05                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Study Trip 1: Jen Library                                                                                      | class      | 11/7/26                                                                     | Sat 2026-11-07                                                                                         | Visit to view a selection of works from the Don Bluth Animation Production Collection, 10 am to 12 pm. Type is nearest fit.                                                                                                                   |
| AI101 | Class 17: Revise | class | Class 17 | Tue 2026-11-10 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: The Disney Renaissance                                                                                | class      | Class 17                                                                    | Tue 2026-11-10                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list. Class also lists Presentation Team Discussions - Assignment 4.                                                                                            |
| ANIM223 | Reading: A New History of Animation, Chapters 19 & 20                                                          | reading    | Class 17                                                                    | Tue 2026-11-10                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| ANIM223 | Presentation Team Discussions - Assignment 4:                                                                  | project    | Class 17                                                                    | Tue 2026-11-10                                                                                         | In-class team time for Assignment 4.                                                                                                                                                                                                          |
| AI101 | Class 18: Confirm the Difference | class | Class 18 | Thu 2026-11-12 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Emergence of Electronic Games & 3D Experimentation                                                    | class      | Class 18                                                                    | Thu 2026-11-12                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list.                                                                                                                                                           |
| ANIM223 | Reading: A New History of Animation, Chapters 21 & 22                                                          | reading    | Class 18                                                                    | Thu 2026-11-12                                                                                         | Listed under this class; syllabus gives no separate due time.                                                                                                                                                                                 |
| AI101 | Class 19: Demo and Defend | class | Class 19 | Tue 2026-11-17 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Japanese Animation                                                                                    | class      | Class 19                                                                    | Tue 2026-11-17                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list. Class also lists DUE: Assignment 3 and DUE: Assignment 4.                                                                                                 |
| ANIM223 | DUE: Assignment 3 - Submit remaining textbook summaries of chapters 12 thru 24.                                | assignment | Class 19; also "Due by the beginning of Class 19" (Class 10)                | Tue 2026-11-17                                                                                         | Grading Opportunities row 3 gives 11/17/26 (matches). Chapters 23 and 24 are not assigned as a Reading in any class.                                                                                                                          |
| ANIM223 | DUE: Assignment 4 - Team Presentation Project                                                                  | project    | Class 19; "The final submission of all slides is by the end of Class 19"    | Tue 2026-11-17                                                                                         | Grading Opportunities row 4 gives 11/17/26 (matches). Class 14 launch says "start of Class 19". Not resolved.                                                                                                                                 |
| AI101 | Capstone: Your Own Agent | project | 11/18/26 | Thu 2026-11-19 | Grading Opportunities date as written: 11/18/26, weight 30%. Moved to Thu 2026-11-19, the date of Class 20 in the Class Meeting Dates list (your decision). |
| AI101 | Professional Practice | assignment | 11/18/26 | Thu 2026-11-19 | Grading Opportunities date as written: 11/18/26, weight 15. Moved to Thu 2026-11-19, the date of Class 20 in the Class Meeting Dates list (your decision). |
| AI101 | Class 20: Reflect and Carry Forward | class | Class 20 | Thu 2026-11-19 | Date from the AI101 Class Meeting Dates list (your decision); Schedule of Classes table date ignored. |
| ANIM223 | Lecture: Technology and Entertainment                                                                          | class      | Class 20                                                                    | Thu 2026-11-19                                                                                         | Schedule table Date column is blank in the PDF; date from Class Meeting Dates list. Class also lists DUE: Assignment 5 - Final Test.                                                                                                          |
| ANIM223 | DUE: Assignment 5 - Final Test - Multiple choice and short answer - In Class Only                              | test       | Class 20                                                                    | Thu 2026-11-19                                                                                         | Grading Opportunities row 5 gives 11/19/26 (matches).                                                                                                                                                                                         |
| AI101 | Study Trip 1 | class | 1 TBD and will announce on BB | NEEDS DATE | Study (Field) Trips table. Type is nearest fit; not a class meeting. |
| AI101 | Extra Help Session 1 | class | 1: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Extra Help Session 2 | class | 2: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Extra Help Session 4 | class | 4: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Extra Help Session 3 | class | 3: Extra Help Session are on Fridays, Date and Time will be announced on BB | NEEDS DATE | Fridays, no date given. Type is nearest fit. Syllabus lists sessions in order 1, 2, 4, 3. |
| AI101 | Midterm Conference(s) | class | scheduled outside of class time with the professor | NEEDS DATE | Standard policy text; no date given. Type is nearest fit; not a test or class meeting. |
| ANIM223 | Acquire the textbook & prepare for Class One                                                                   | assignment | by the beginning of the quarter; "prepare for Class One"                    | NEEDS DATE                                                                                             | Pre-quarter Assignment. Syllabus gives no quarter start date. Class One is listed as Tue 2026-09-15 but the textbook deadline is worded as "beginning of the quarter". Also asks for a Discord volunteer and Blackboard review, no dates.     |
| ANIM223 | Over the weekend teams will establish a team discord, discuss and determine their 1st and 2nd choice of topic. | assignment | Over the weekend (listed under Class 14)                                    | NEEDS DATE                                                                                             | No weekend date given.                                                                                                                                                                                                                        |
| ANIM223 | Midterm Conference(s)                                                                                          | class      | scheduled outside of class time with the professor                          | NEEDS DATE                                                                                             | Standard policy text; no date given. Type is nearest fit; not a test or class meeting.                                                                                                                                                        |

## Date references found but not entered as items

These have no type that fits (class / no class / reading / assignment / project / test) and are not syllabus-assigned work. I did not guess dates for them.

- AI101: "free GitHub account (set up in class, Week 2)". The syllabus lists no week dates, so "Week 2" was not converted.
- AI101 and ANIM223: "Course evaluations ... during Weeks 8, 9, and 10 through MySCAD". No week dates listed, not converted.
- ANIM223 Suggested Extended Learning Opportunities (optional, dated as written, no year given): SCAD AnimationFest, Wednesday, Sept. 23 - Friday, Sept. 25 (Atlanta); Digital Presence: Portfolios for Animators, VFX Artists, and More!, Friday, Oct. 16, 3pm - 4pm; SCAD Savannah Film Festival, Saturday, Oct. 24 - Saturday, Oct. 31.
- ANIM223 office hours: Fridays from 9am to 11 am (recurring, no dates). AI101 office hours: TBD.

## Other things to check

- ANIM223: Class 14 launch says Assignment 4 is due by the start of Class 19. The Class 19 row says the final submission of slides is by the end of Class 19. Both are listed; neither chosen.
- ANIM223: Assignment 3 covers chapters 12 thru 24, but readings are only assigned through chapter 22. Chapters 23 and 24 appear in no class.
- ANIM223: Assignment 1 is named "Unit 1 Paper" at launch, and "Written summaries of textbook chapters 1 thru 11" in Grading Opportunities. Both names kept as written, on separate rows.
- ANIM223 Class 10 (Thu 2026-10-15) has the Midterm Test and Assignment 1 due, plus Extra Help Session 1 that afternoon. Flagged for step 4; not resolved here.
- The two PDFs were captured on different dates (ANIM223 on 9/8/26, AI101 on 10/4/26). Worth confirming ANIM223 is still the latest version.

## Step 2 report: step-2-report.md
# Step 2 report: Extract every dated item

Output: `outputs/dated-items.md`. Step 3 has not been started.

| | Items | `NEEDS DATE` | Other flags |
|---|---|---|---|
| AI101 | 32 | 6 | none |
| ANIM223 | 45 | 3 | none |

Neither syllabus marks any `no class` days.

## AI101 date source: resolved by you

- **Your decision:** AI101 dates come from the Class Meeting Dates list (Class 1 = Tue 9/15/26). The Schedule of Classes table dates are ignored.
- **Applied:** all 21 `DATE CONFLICT` rows now show the list date.
- **Grading Opportunities dates:** moved to the Thursday class dates, as you decided.
  - Project 1: 9/23 to Thu 9/24 (Class 4).
  - Project 2: 10/7 to Thu 10/8 (Class 8).
  - Project 3: 10/21 to Thu 10/22 (Class 12).
  - Capstone and Professional Practice: 11/18 to Thu 11/19 (Class 20).
  - The original written date stays in "As written" and Notes.

## Other things to check

- **ANIM223 Assignment 4:** Class 14 says it's due at the start of Class 19, and the Class 19 row says by the end of Class 19. Both are listed.
- **ANIM223 Assignment 3 readings:** It covers chapters 12–24, but readings are only assigned through chapter 22.
- **ANIM223 dates:** The schedule table's Date column is blank in the PDF, so I used its Class Meeting Dates list.
- **PDF versions:** The ANIM223 PDF was captured 9/8/26, and the AI101 PDF 10/4/26. Confirm ANIM223 is still the latest version.

## Judgment calls

- **Extra rows:** I used type `class` for study trips, extra help sessions and midterm conferences, since no type fits. Each row's Notes says so.
- **Left out of the table:** Course evaluations (Weeks 8–10), the "Week 2" GitHub setup, and the optional ANIM223 events. They are listed at the bottom of `dated-items.md`.
- **Where the file lives:** The step files point to `outputs/dated-items.md`, so I saved it there. `outputs/README.md` suggests a `first-run` prefix, and the empty `outputs/first-run/` folder is still there.

## Your human check

- Pick three items per course and compare them with the syllabi.
- Tell the model when to continue.

## Step 3: calendar.md
# Calendar (Step 3)

Built from `outputs/dated-items.md` only. Title format: `[Course] Type: exact item name`. AI101 dates follow the Class Meeting Dates list and the Grading Opportunities moves you decided in step 2.

**Events: 68** (AI101 26, ANIM223 42). **Not yet scheduled: 9.**

## Recurring

- ANIM223 professor office hours: Fridays, 9 am to 11 am. Syllabus gives no start or end dates, so they are not placed on individual dates.
- AI101 professor office hours: TBD in the syllabus. Nothing to add.
- Weekly class meetings (Tuesday / Thursday for both courses) appear as the individual Class rows below.

## Week of Sep 14–Sep 20

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-09-15 | Tue | AI101 | [AI101] Class: Class 1: Set Up Your Practice |
| 2026-09-15 | Tue | AI101 | [AI101] Assignment: Your Agent Brief |
| 2026-09-15 | Tue | ANIM223 | [ANIM223] Class: Lecture: The Beginning |
| 2026-09-15 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation - Chapters 1 &2 |
| 2026-09-15 | Tue | ANIM223 | [ANIM223] Assignment: Launch Assignment 1: Unit 1 Paper |
| 2026-09-17 | Thu | AI101 | [AI101] Class: Class 2: Make Something |
| 2026-09-17 | Thu | ANIM223 | [ANIM223] Class: Lecture: Innovation & Experimentation in the early Silent Era |

## Week of Sep 21–Sep 27

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-09-22 | Tue | AI101 | [AI101] Class: Class 3: See the Whole Room |
| 2026-09-22 | Tue | ANIM223 | [ANIM223] Class: Lecture: Growth of the Animation Industry in the 1920's |
| 2026-09-22 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation - Chapters 3 & 4 |
| 2026-09-24 | Thu | AI101 | [AI101] Project: Project 1: Make, Then Compare |
| 2026-09-24 | Thu | AI101 | [AI101] Class: Class 4: Name the Trade |
| 2026-09-24 | Thu | ANIM223 | [ANIM223] Class: Lecture: Animation Matures as an Art Form |
| 2026-09-24 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation - Chapter 5 & 6 |

## Week of Sep 28–Oct 4

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-09-29 | Tue | AI101 | [AI101] Class: Class 5: Name the Process |
| 2026-09-29 | Tue | ANIM223 | [ANIM223] Class: Lecture: First Features and Better Storytelling with Improved Believability |
| 2026-10-01 | Thu | AI101 | [AI101] Class: Class 6: Verify Your Sources |
| 2026-10-01 | Thu | ANIM223 | [ANIM223] Class: Lecture: Warner Bros. |
| 2026-10-01 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 7 & 8 |

## Week of Oct 5–Oct 11

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-06 | Tue | AI101 | [AI101] Class: Class 7: Build a Pipeline |
| 2026-10-06 | Tue | ANIM223 | [ANIM223] Class: Lecture: MGM and other Hollywood studios |
| 2026-10-08 | Thu | AI101 | [AI101] Project: Project 2: Small Orchestration |
| 2026-10-08 | Thu | AI101 | [AI101] Class: Class 8: Take Feedback, Iterate |
| 2026-10-08 | Thu | ANIM223 | [ANIM223] Class: Lecture: Wartime Animation |
| 2026-10-08 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapter 9 |

## Week of Oct 12–Oct 18

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-13 | Tue | AI101 | [AI101] Class: Class 9: Disclosure and Position |
| 2026-10-13 | Tue | ANIM223 | [ANIM223] Class: Lecture: Post-War and Midcentury Developments |
| 2026-10-13 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 10 & 11 |
| 2026-10-15 | Thu | AI101 | [AI101] Class: Class 10: Study Your Field |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Class: Lecture: Rise of Stop Motion |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Assignment: DUE: Assignment 1 - Submit remaining textbook summaries of chapters 1 thru 11. |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Test: DUE: Assignment 2 - Midterm Test - Multiple choice and short answer - In Class Only |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Assignment: Launch Assignment 3: Unit 3 Paper |
| 2026-10-15 | Thu | ANIM223 | [ANIM223] Class: Extra Help Session 1 |

## Week of Oct 19–Oct 25

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-20 | Tue | AI101 | [AI101] Class: Class 11: Build for Your Field |
| 2026-10-20 | Tue | ANIM223 | [ANIM223] Class: Lecture: Animation Moves to the Small Screen as Live Action Did |
| 2026-10-20 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 12 & 13 |
| 2026-10-22 | Thu | AI101 | [AI101] Project: Project 3: Your Field, With AI |
| 2026-10-22 | Thu | AI101 | [AI101] Class: Class 12: Crit and Revise |
| 2026-10-22 | Thu | ANIM223 | [ANIM223] Class: Lecture: Experimentation and Computers |

## Week of Oct 26–Nov 1

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-10-27 | Tue | AI101 | [AI101] Class: Class 13: Define Your Agent |
| 2026-10-27 | Tue | ANIM223 | [ANIM223] Class: Lecture: The Beginning of a Decline in Animated Theatrical Features |
| 2026-10-27 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 14 & 15 |
| 2026-10-29 | Thu | AI101 | [AI101] Class: Class 14: Assemble the Sources |
| 2026-10-29 | Thu | ANIM223 | [ANIM223] Class: Lecture: Bluth, Bakshi, & Williams |
| 2026-10-29 | Thu | ANIM223 | [ANIM223] Project: Launch Assignment 4 Team Presentation Project - All are Due by start of Class 19 |

## Week of Nov 2–Nov 8

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-11-03 | Tue | AI101 | [AI101] Class: Class 15: Build and Test |
| 2026-11-03 | Tue | ANIM223 | [ANIM223] Class: Lecture: Animation Festivals & Short Films |
| 2026-11-03 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 16, 17, & 18 |
| 2026-11-05 | Thu | AI101 | [AI101] Class: Class 16: Find the Failures |
| 2026-11-05 | Thu | ANIM223 | [ANIM223] Class: Lecture: Animation in Canada |
| 2026-11-07 | Sat | ANIM223 | [ANIM223] Class: Study Trip 1: Jen Library |

## Week of Nov 9–Nov 15

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-11-10 | Tue | AI101 | [AI101] Class: Class 17: Revise |
| 2026-11-10 | Tue | ANIM223 | [ANIM223] Class: Lecture: The Disney Renaissance |
| 2026-11-10 | Tue | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 19 & 20 |
| 2026-11-10 | Tue | ANIM223 | [ANIM223] Project: Presentation Team Discussions - Assignment 4: |
| 2026-11-12 | Thu | AI101 | [AI101] Class: Class 18: Confirm the Difference |
| 2026-11-12 | Thu | ANIM223 | [ANIM223] Class: Lecture: Emergence of Electronic Games & 3D Experimentation |
| 2026-11-12 | Thu | ANIM223 | [ANIM223] Reading: Reading: A New History of Animation, Chapters 21 & 22 |

## Week of Nov 16–Nov 22

| Date | Day | Course | Event |
|---|---|---|---|
| 2026-11-17 | Tue | AI101 | [AI101] Class: Class 19: Demo and Defend |
| 2026-11-17 | Tue | ANIM223 | [ANIM223] Class: Lecture: Japanese Animation |
| 2026-11-17 | Tue | ANIM223 | [ANIM223] Assignment: DUE: Assignment 3 - Submit remaining textbook summaries of chapters 12 thru 24. |
| 2026-11-17 | Tue | ANIM223 | [ANIM223] Project: DUE: Assignment 4 - Team Presentation Project |
| 2026-11-19 | Thu | AI101 | [AI101] Project: Capstone: Your Own Agent |
| 2026-11-19 | Thu | AI101 | [AI101] Assignment: Professional Practice |
| 2026-11-19 | Thu | AI101 | [AI101] Class: Class 20: Reflect and Carry Forward |
| 2026-11-19 | Thu | ANIM223 | [ANIM223] Class: Lecture: Technology and Entertainment |
| 2026-11-19 | Thu | ANIM223 | [ANIM223] Test: DUE: Assignment 5 - Final Test - Multiple choice and short answer - In Class Only |

## Not yet scheduled

| Course | Event | As written |
|---|---|---|
| AI101 | [AI101] Class: Study Trip 1 | 1 TBD and will announce on BB |
| AI101 | [AI101] Class: Extra Help Session 1 | 1: Extra Help Session are on Fridays, Date and Time will be announced on BB |
| AI101 | [AI101] Class: Extra Help Session 2 | 2: Extra Help Session are on Fridays, Date and Time will be announced on BB |
| AI101 | [AI101] Class: Extra Help Session 4 | 4: Extra Help Session are on Fridays, Date and Time will be announced on BB |
| AI101 | [AI101] Class: Extra Help Session 3 | 3: Extra Help Session are on Fridays, Date and Time will be announced on BB |
| AI101 | [AI101] Class: Midterm Conference(s) | scheduled outside of class time with the professor |
| ANIM223 | [ANIM223] Assignment: Acquire the textbook & prepare for Class One | by the beginning of the quarter; "prepare for Class One" |
| ANIM223 | [ANIM223] Assignment: Over the weekend teams will establish a team discord, discuss and determine their 1st and 2nd choice of topic. | Over the weekend (listed under Class 14) |
| ANIM223 | [ANIM223] Class: Midterm Conference(s) | scheduled outside of class time with the professor |

## Flags carried over from dated-items.md (nothing resolved here)

- ANIM223 Assignment 4: Class 14 launch says due at the start of Class 19; the Class 19 row says by the end of Class 19. Calendar shows Tue 2026-11-17.
- Rows titled "Launch Assignment ..." are launch dates, not due dates. "Presentation Team Discussions" is in-class team time. All are listed as assignment/project rows because the dated list types them that way.
- Readings, study trips and extra help sessions are included because they have dates in the dated list; the step 3 directions name only classes, assignments, projects and tests.

## Step 4: overlaps.md
# Overlaps (Step 4)

Built from `outputs/calendar.md`. Counted as "due" are calendar rows typed assignment, project, or test (68 events total, 15 of them due items). Weeks run Monday through Sunday. Nothing here is a suggestion or a ranking; what to do about each overlap is your decision.

**Overlaps found: 4** (2 same day, 2 heavy week). No week has a test in both courses: AI101 has no test, and ANIM223 has two (Thu 2026-10-15 and Thu 2026-11-19), in different weeks.

| Dates | Items (course + exact name) | Why it is flagged |
|---|---|---|
| Tue 2026-09-15 | AI101: Your Agent Brief<br>ANIM223: Launch Assignment 1: Unit 1 Paper | same day. The ANIM223 row is a launch date, not a due date; counted because the calendar types it as an assignment. |
| Mon 2026-10-12 to Sun 2026-10-18 (all on Thu 2026-10-15) | ANIM223: DUE: Assignment 1 - Submit remaining textbook summaries of chapters 1 thru 11.<br>ANIM223: DUE: Assignment 2 - Midterm Test - Multiple choice and short answer - In Class Only<br>ANIM223: Launch Assignment 3: Unit 3 Paper | heavy week (3 items, all ANIM223; one is a launch date, not a due date). No AI101 item in this week. |
| Mon 2026-11-16 to Sun 2026-11-22 | ANIM223: DUE: Assignment 3 - Submit remaining textbook summaries of chapters 12 thru 24. (Tue 11/17)<br>ANIM223: DUE: Assignment 4 - Team Presentation Project (Tue 11/17)<br>AI101: Capstone: Your Own Agent (Thu 11/19)<br>AI101: Professional Practice (Thu 11/19)<br>ANIM223: DUE: Assignment 5 - Final Test - Multiple choice and short answer - In Class Only (Thu 11/19) | heavy week (5 items across both courses) |
| Thu 2026-11-19 | AI101: Capstone: Your Own Agent<br>AI101: Professional Practice<br>ANIM223: DUE: Assignment 5 - Final Test - Multiple choice and short answer - In Class Only | same day (3 items, both courses) |

## Notes

- ANIM223 Assignment 4 is listed on Tue 2026-11-17, but the syllabus says both "start of Class 19" and "end of Class 19". Same date either way, so it does not change the flag.
- Tue 2026-11-17 has two ANIM223 items due and nothing from AI101, so it is not a same-day overlap. It is inside the heavy week above.
- Weeks with fewer than three due items and no cross-course same day are not listed. Their counts: Sep 14 week 2 (the same-day row above), Sep 21 week 1, Oct 5 week 1, Oct 19 week 1, Oct 26 week 1, Nov 9 week 1.
- Today is 2026-10-10. The Tue 2026-09-15 overlap is already past. The other three are still ahead; the Oct 12 week starts Monday.
- Items in `Not yet scheduled` in `calendar.md` are not counted. Six AI101 and three ANIM223 items have no date, so the flagged weeks could change once those are dated.
