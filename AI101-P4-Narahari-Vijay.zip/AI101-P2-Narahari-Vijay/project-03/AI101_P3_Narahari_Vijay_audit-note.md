# audit-note.md


## The workflow I audited

Syllabus to calendar, and it turns my course syllabi into one calendar with due dates and overlaps. 

## The stress test

I used project-02/input/stress-test/AI101-syllabus.md instead of AI101.pdf because to compare the results with the codex output, I had to use a text readable file. In this syllabus, the class dates mismatched (class meeting date vs. schedule of classes date) I ran it in Claudian with the following steps: 

**Prompts:**

1)    I’m running my Project 2 workflow. The input is only project-02/input/stress-test/AI101-syllabus.md. Save any files you create in project-03/outputs/p2-stress-test/. Don’t change anything in project-02/.

Follow project-02/01-collect-syllabi.md.

2)    Follow project-02/02-extract-dated-items.md.

3)    Follow project-02/03-add-events.md.

4)    Follow project-02/04-check-overlaps.md.

5)    Follow project-02/05-review-weekly.md.

I expected the agent to catch the date mismatch and ask for a check from a human
## What happened

Claudian used AGENTS.md, without me specifying it to do so, by exploring the vault of its own because my skills folder isn’t inside project-02 or project-03 and it sits on the top level of the vault. My p2-run was partly an agent run. The dates didn’t match exactly in the input file. However, the agent worked out a mapping by itself, and then decided no human check was needed, because it used my decision-note even though I didn’t specify in my steps. Apart from this, the Agent did well in leaving the undated items unscheduled, and flagging the events overlap on 11/19 without ranking the priority. the agent asked me what it needed moved the grading opportunity date without asking. I am going to add the fix regarding that now.
## The fix

I am going to make a change in project-02/02-extract-dated-items.md.

Copy due dates from the Grading Opportunities table exactly as written. If a due date doesn’t match a class meeting date, list both and ask me. Don’t move a due date. Make sure this overrides the decision note for due dates, because I don’t want to be late on my grading opportunity date. 

p2-run-3 fix: I just changed the wording in 02-extract-dated-items.md regarding using the decision-note to make it more affirmative by asking the agent to override my decision-note.md.  I renumbered the rules again but without changing order because the formatting changed the numbering.
## What the fix changed

|                         | p2-run                                                          | p2-run-2                                                                          | p2-run-3                                                                          |     |
| ----------------------- | --------------------------------------------------------------- | --------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- | --- |
| **5 grading due dates** | Moved each one a day later on its own and did not ask the human | Left all five as NEEDS DATE, showed both dates side by side, and asked me to pick | Left all five as NEEDS DATE, showed both dates side by side, and asked me to pick |     |
| **Calendar due dates**  | 6 (pre-quarter assignment + 5 grading items)                    | 1 (only the pre-quarter assignment); the other 5 wait on my answer                | 1 (only the pre-quarter assignment); the other 5 wait on my answer                |     |
| **Course evaluations**  | Guest the dates as (Nov 2–22),                                  | The agent did not guess                                                           | The agent did not guess                                                           |     |

## What I learned about my workflow

The agent made some assumptions regarding my grading due dates and I was able to fix them after I added the extra working to my step 2.

Then commit the fix on its own before rerunning:

bash

git add project-02/02-extract-dated-items.md

git commit -m "Fix P2 step 02: don't move grading due dates"
