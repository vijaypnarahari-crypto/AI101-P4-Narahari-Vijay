# source-index.md


| Reference                                           | Where it came from                                                                                  | What it is for in the build                                                                                      | Permission                                                    |
| --------------------------------------------------- | --------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------- |
| plan.md                                             | My project folder                                                                                   | Defines the user (Brian), the build sentence, the boundaries, and the rejected idea                              | Yours                                                         |
| prd.md                                              | My project folder                                                                                   | Tells the AI what to build: features, what happens, look and feel, out of scope, and done-when checks            | Yours                                                         |
| ADR-001-one-html-file.md                            | My project folder                                                                                   | Decision to build the whole game as one HTML file with nothing to install                                        | Yours                                                         |
| ADR-002-built-in-images-fonts-data.md               | My project folder                                                                                   | Decision to use the 🚗 emoji, system fonts, and random numbers made in JavaScript                                | Yours                                                         |
| Color Catch sample PRD and ADRs                     | Color Catch sample PRD and ADRs                                                                     | Unicode standard, drawn by each laptop's built-in emoji font (Apple on macOS, Microsoft on Windows)              | Course file                                                   |
| 🚗 emoji (U+1F697)                                  | Unicode standard, drawn by each laptop's built-in emoji font (Apple on macOS, Microsoft on Windows) | The cars Brian counts                                                                                            | Public standard; emoji fonts are part of the operating system |
| System fonts                                        | Already installed on the laptop (macOS or Windows) \| Title, numbers, buttons, and messages         | Title, numbers, buttons, and messages                                                                            | Part of the operating system                                  |
| Rows of five for counting                           | Common Pre-K counting practice (ten-frames)                                                         | How the cars are arranged on screen                                                                              | Public teaching method                                        |
| ADR-003-wrong-answers-are-close-to-the-right-one.md | My project folder                                                                                   | Cycle 2 decision to make the two wrong choices within 3 of the right answer                                      | Yours                                                         |
| ADR-004-gold-medal-reward                           | My project folder                                                                                   | Professor Madrid gave feedback to add gameplay rewards so Brian can be engaged and motivated to continue playing | Yours                                                         |
## AI-generated assets

- **Game code:** The HTML, CSS, and JavaScript in `build/index.html`, including the confetti effect, were written by AI from my prd.md.

- **Planning documents:** I drafted some parts of  prd.md, ADR-001, and ADR-002 with help from Claude, then edited and approved the final wording myself.

- **Images and sounds:** None. The cars are the built-in 🚗 emoji, and the game has no sounds.

## Permitted material

	I confirm this folder holds no classmates' work, no unlicensed files, no personal data, and no passwords or keys. "Brian" is used only as a first name for the user, and no other details about him are included.


