# reflection.md

*Write this in your own words in Class 20. This is the part a model must not write. Delete the italic guidance lines before you submit.*

## What AI did
Claude wrote all the code in build/index.html, built the first version for my PRD and ADRs, then updated it twice: for ADR-003, so the wrong answers stay within 3 of the right one, and for ADR-004, which added the gold medal board and the "Yay! You Are A Math Star!" celebration. It also drafted the wording for my plan answers, PRD sections, ADRs, README, source index, disclosure, and testing log tables, and it suggested ideas like rows of five, close wrong answers, and stickers or star badges as rewards. It explained things I didn't know, like what an ADR is, how the game runs offline, and how to keep Claudian inside my project folder.

## What stayed mine

I created the fictional user, student Brian, and made sure the game only features cars up to 20. No numbers beyond 20, timer, losing points, or showing the word "wrong" or a red X were the boundaries I wrote. Moreover, I made sure whenever Brian chooses the wrong answer, it keeps the same question to count again, rejected typing answers, found the problem in c1-issue-noticed.png, where the choices were so far apart from each other, which I fixed in Cycle 2. For the reward, I picked gold medals, 5 correct answers per medal, the 2-by-5 board, and the reset after 10. I also ran every test and marked every result. 

## What this agent still gets wrong

The flaw I did not fix was with the game's written messages, "Good job!" and "Let's count again!", Brian can't read it well since he is a Pre-K student. Without a parent reading it aloud, he can only tell by the confetti if he chooses the correct answer. I left it this way because I included no sounds in scope to keep the game simple, and that adding spoken messages would change the decision and require its own ADR and testing. I also noticed that there are a few times when confetti does not appear when he chooses the correct answer.

## What I carry forward

 I would probably push this game by fixing and adding some new features to keep the game motivating to play by probably creating original artwork instead of using images, or I may create a similar game but in 3D and probably an open world utilizing my major and field 3D animation. 

## What I would change with one more week

I would add sound for the messages "Good job!" and "You are A Math Star!", and sounds for the confetti and when he receives a medal. I would also add voice for my messages so Brian can easily understand without guessing.
