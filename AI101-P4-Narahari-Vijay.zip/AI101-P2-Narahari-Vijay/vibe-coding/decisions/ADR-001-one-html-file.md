# ADR-001: One HTML file

**Status:** accepted (Class 14) 

**Context:** Count With Me is a small game for one Pre-K student, and it has to open from build/index.html on any laptop, with nothing to install.

**Decision:** Build the whole game as one HTML file, with the HTML, CSS, and JavaScript together and no outside images, libraries, or servers.

**Consequence:** It’s easy to open, share, and review, because every change is in one place. But it’s harder to organize if the game grows.

