# ADR-002: Built-in images, fonts, and data

**Status:** accepted (Class 14) 

**Context:** ADR-001 makes this game one HTML file that opens on any laptop with nothing to install. So the car pictures, the fonts, and the numbers for each round can't come from outside files, image websites, or a server, or the game could break when it's offline or moved to another laptop. 

**Decision:** The cars are the 🚗 emoji, which every laptop already has. The text uses the laptop's own rounded system fonts, with no downloaded fonts. The numbers for each round (how many cars, and the two wrong choices) are picked at random by JavaScript inside the file, with no data file. 

**Consequence:** The game works offline and has nothing extra to download. But the emoji and text may look different on macOS and Windows, and I can’t use custom car art, like my own drawing or a picture of a specific car, because that would be an outside image file and break the one-file rule. 

