# tests

Save a screenshot or a short screen recording of every test here, before you decide what it means.

Name each file by cycle and test, for example `c1-main.png`, `c1-edge.mp4`, `c2-scope.png`.

The interpretation goes in `../testing-and-failure-log.md`. This folder holds the evidence the log points to, so a reader can check a claim without re-running your build.


![[c1-unexpected.png]]

![[c1-main.png]]

![[c1-scope.png]]

![[c1-issue-noticed.png]]

![[c1-edge.png]]![[c2-scope.png]]

![[c2-unexpected.png]]

![[c2-main.png]]

![[Screenshot 2026-11-09 at 12.40.21 PM.png]]![[c2-medal-scope.png]]![[c2-medal-main.png]]![[c2-medal-unexpected.png]]![[c2-medal-edge.png]]![[c2-medal-first-medal.png]]![[c2-medal-math-star.png]]