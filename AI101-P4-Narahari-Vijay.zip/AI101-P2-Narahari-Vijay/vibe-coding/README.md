# README.md

*This file ships with your build. A classmate should be able to open the build and run one test without asking you anything. Delete the italic guidance lines before you submit.*

# Count With Me

**Option:** Game

**Build sentence:** When Brian opens the page, counts the cars on screen, and clicks one of three number choices, the game responds with confetti, "Good job!", and +1 point if he's correct, or "Let's count again!" with his points unchanged if he's wrong. Every 5 correct answers earns a gold medal, and for 10 gold medals, he gets a "You Are A Math Star!" message on screen.

## How to open it

Open `build/index.html` in a current browser (Chrome, Safari, and others) by double-clicking it in Finder or File Explorer. It needs no internet, installs, or logins.

## What it will not do

- Show a number above 20 
- Take away points or medals for a wrong answer 
- Use a timer or rush the player 
- Say the word "wrong" or show a red X 
- Show mean or scary messages 
- Let the player type an answer 
- Play sounds, save the score, or ask for a name or account
## Known limits

- **Nothing is saved.** Closing or refreshing the page resets the score and the medals to 0 (see ADR-004). 
- **Emoji look different on different laptops.** The 🚗 and 🥇 are drawn by the operating system, so they look slightly different on macOS and Windows (see ADR-002). 
- **The full medal board takes a while.** Reaching all 10 medals and "Yay! You Are A Math Star!" takes 50 correct answers. See tests/c2-medal-math-star.png
- **Answer choices are close to each other making the game more challenging** The answer choices are close to each other so rounds with 15–20 cars take careful counting and may bring more "Let's count again!" messages (see ADR-003 and tests/c2-medal-unexpected.png). 
- **Made for a laptop screen.** All tests were run only on a laptop.
- **Messages are written words.** A Pre-K child who can't read yet may need a grown-up to read "Good job!", "Let's count again!", "You earned a gold medal!", and "You Are A Math Star" aloud, since the game has no sounds.