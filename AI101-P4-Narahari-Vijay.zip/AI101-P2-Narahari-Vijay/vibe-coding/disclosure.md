# disclosure.md


## What AI contributed

- Explained what vibe coding is and suggested YouTube videos to watch. 
- Drafted the PRD sections (What happens, Look and feel, Out of scope, Done when), including the color palette (sunny yellow, sky blue, grass green on cream), and kept the PRD consistent with my plan.
- Suggested three possible features (tap to count, read aloud, rows of five). I kept rows of five and left out the other two.
- AI Suggested making the two wrong answers close to the correct one. I decided to drop that rule.
- Pointed out that wrong answers could go above 20 or below 1, which led me to add the "between 1 and 20" rule.
- Suggested topics and drafted wording for ADR-001 (one HTML file) and ADR-002 (built-in images, fonts, and data), and explained what ADRs are for.
- Suggested and drafted ADR-003, and changed the answer-choice code in `build/index.html` for ADR-003.
- Helped me draft ADR-004, and changed build/index.html.
## What I decided

- I came up the idea (a counting game for a Pre-K student) and the user, Brian. The game uses car emoji  and counting up to 20.
- Decided on three number choices (one correct, two incorrect), confetti and "Good job!" for right answers, "Let's count again!" for wrong ones, and +1 point with no points taken away.
- Decided that after a correct answer a new set of cars appears, and after a wrong answer the same question stays on screen.
- Wrote the boundaries: no numbers above 20, no timer, no subtracting points, no word "wrong" or red X, nothing mean or scary.
- Decided the rejected idea (typing answers) and the reason.
- Added the title "Count With Me," the screen layout (title top center, score top right, cars in the middle, buttons at the bottom), and the no-scrolling rule.
- Decided what is out of scope, including sounds, saved scores, accounts, and menus.
- Set the Done when checks, including playing ten rounds.
- Found the guessing problem in Cycle 1 (`c1-issue-noticed.png`), chose that change for Cycle 2, and ran and marked the Cycle 2 tests.
- I decided on the reward features where Brian gets a gold medal for every 5 correct answers and the celebratory messages.

## Tools used

- Claude.ai, Obsidian, Claudian with Cluade code
